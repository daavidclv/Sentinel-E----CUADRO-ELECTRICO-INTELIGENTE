/* ============================================================================
 * FASE SCT � alarma_corriente_ac.h
 * Motor de alarma de corriente ALTERNA (red, via SCT-013-005).
 *
 * A diferencia de alarma_motor (temperatura, umbral simple) y
 * alarma_corriente (corriente DC, umbral simple), esta alarma vigila una
 * BANDA de funcionamiento normal [UMBRAL_BAJO, UMBRAL_ALTO]. Salir de la
 * banda por arriba o por abajo dispara la misma alarma sonora/visual, pero
 * el motivo (ALTA/BAJA) se reporta a NUCLEO-A para el historial.
 *
 * Patron sonoro: doble-beep agudo a 2800 Hz (60ms ON/60ms OFF x2, luego
 * 300ms de silencio). Inconfundible frente a:
 *   - Temperatura: sirena barrida continua 2000-3500 Hz
 *   - Corriente DC: beep simple fijo a 1500 Hz, 100/100ms
 *
 * LEDs: parpadeo ALTERNO cruzado LED0/LED1 a 5 Hz (cuando uno se enciende
 * el otro se apaga), distinto del parpadeo simultaneo de los 3 LEDs que usa
 * la alarma de corriente DC.
 * ========================================================================== */
#ifndef ALARMA_CORRIENTE_AC_H
#define ALARMA_CORRIENTE_AC_H

#include <stdint.h>
#include <stdbool.h>
#include "cmsis_os2.h"

/* Banda de funcionamiento normal por defecto, en centiamperios (cA).
 * Sobrescribibles por NUCLEO-A via D:<bajo_cA>,<alto_cA> */
#define ALARMA_AC_UMBRAL_BAJO_DEFAULT_CA    60U    /* 0.60 A */
#define ALARMA_AC_UMBRAL_ALTO_DEFAULT_CA   170U    /* 1.70 A */

/* Histeresis en cA: para volver a "normal" hay que entrar este margen
 * dentro de la banda, no solo rozar el umbral. Evita parpadeo en el borde. */
#define ALARMA_AC_HYSTERESIS_CA              5U    /* 0.05 A */

/* Motivo de la alarma, reportado a A en la trama AQ: */
typedef enum {
    ALARMA_AC_MOTIVO_NINGUNO = 0,   /* alarma inactiva */
    ALARMA_AC_MOTIVO_ALTA    = 1,   /* corriente > umbral alto */
    ALARMA_AC_MOTIVO_BAJA    = 2    /* corriente < umbral bajo */
} alarma_ac_motivo_t;

/* Inicializa el motor de alarma de corriente AC. Llamar una vez al arranque,
 * DESPUES de Motor_Alarma_Init() (que es quien inicializa el PWM/TIM1
 * compartido). NO reinicializa el PWM. */
int Motor_CorrienteAC_Init(void);

/* Llamado cada vez que hay nueva lectura de corriente AC del SCT-013,
 * en centiamperios (mismo formato que g_corriente_ac_cA en A). */
void Motor_CorrienteAC_OnNewMeasurement(uint16_t corriente_ac_cA);

/* Llamado por el parser de fibra cuando llega D:<bajo>,<alto> desde A. */
void Motor_CorrienteAC_SetUmbrales(uint16_t umbral_bajo_cA, uint16_t umbral_alto_cA);

/* Consulta de estado (para inhibir Stop Mode si aplica, igual que las otras). */
bool Motor_CorrienteAC_IsActive(void);

/* Getters para diagnostico/respuesta a ?D */
uint16_t Motor_CorrienteAC_GetUmbralBajo(void);
uint16_t Motor_CorrienteAC_GetUmbralAlto(void);

#endif /* ALARMA_CORRIENTE_AC_H */