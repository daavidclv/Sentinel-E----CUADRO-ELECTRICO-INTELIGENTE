/*------------------------------------------------------------------------------
 * MDK Middleware - Component ::Network
 * HTTP_Server.c - NUCLEO-A (nodo central Sentinel E)
 *----------------------------------------------------------------------------*/

/* ============================ INCLUDES ============================ */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>                     // atof, atoi
#include "main.h"
#include "rtc.h"                        // RTC: fecha/hora del sistema
#include "LCD.h"                        // Driver LCD de la placa
#include "rl_net.h"                     // Stack de red Keil MDK-Pro (HTTP, SNTP)
#include "LEDs.h"                       // Driver LEDs (LED_Expo, LED_Encendido...)
#include "stm32f4xx_hal.h"              // HAL de STM32F4
#include "sntp.h"                       // Cliente SNTP (sincronizacion horaria)
#include "botonazul_rst.h"              // Boton azul (reset/eventos)
#include "memoria_externa.h"            // Driver W25Q128 (flash SPI externa)
#include "historial.h"                  // Registro de eventos en flash externa
#include "aplicacion_rfid.h"            // Driver RFID local (en desuso, se quita)
#include "fibra_opt.h"                  // UART sobre fibra optica hacia NUCLEO-B
#include "acceso_maestro.h"             // Logica desbloqueo web por UID RFID
#include "configuracion.h"              // Parametros persistentes (ID, umbrales)


#define RTE_Drivers_USART2              // Habilita driver USART2 (fibra)

/* ============================ STACKS DE HILOS ============================ */

// Stack del hilo principal de aplicacion (multiplo de 8 bytes por AAPCS)
#define APP_MAIN_STK_SZ (2048U)         // 2 KB - vigilar overflow si crece
uint64_t app_main_stk[APP_MAIN_STK_SZ / 8];
const osThreadAttr_t app_main_attr = {
  .stack_mem  = &app_main_stk[0],
  .stack_size = sizeof(app_main_stk)
};

// Stack dedicado para hilo TX de fibra (printf consume mucha pila)
static uint64_t fiber_tx_stk[1024 / 8];
static const osThreadAttr_t fiber_tx_attr = {
    .name = "FiberTx", .stack_mem = fiber_tx_stk, .stack_size = sizeof(fiber_tx_stk)
};

// Stack dedicado para hilo RX de fibra (parser + printf)
static uint64_t fiber_rx_stk[1024 / 8];
static const osThreadAttr_t fiber_rx_attr = {
    .name = "FiberRx", .stack_mem = fiber_rx_stk, .stack_size = sizeof(fiber_rx_stk)
};

/* ============================ EXTERNOS ============================ */
//extern uint16_t AD_in          (uint32_t ch);                 // Lectura ADC (web)
extern uint8_t  get_button     (void);                        // Lectura boton (web)
extern void     netDHCP_Notify (uint32_t if_num, uint8_t option,
                                const uint8_t *val, uint32_t len);

extern uint8_t modo_leds;                                     // Modo actual LEDs
extern char lcd_text[2][20+1];                                // Buffer texto LCD
extern char aShowTime[80];                                    // Hora formateada
extern char aShowDate[80];                                    // Fecha formateada

char aShowStamp[40];   // FASE HIST-v3: "dd/mm/aaaa HH:MM:SS" para el historial

extern uint16_t g_umbral_temp_c;
extern uint16_t g_umbral_corriente_mA;

/* === FASE AC: umbrales de banda normal de corriente AC (SCT-013), en
 * centiamperios. Por defecto: 0.60-1.70 A (60-170 cA). */
uint16_t g_umbral_ac_bajo_cA = 60U;    /* 0.60 A por defecto */
uint16_t g_umbral_ac_alto_cA = 170U;   /* 1.70 A por defecto */

/* ============================ VARIABLES GLOBALES ============================ */
// Telemetria recibida desde NUCLEO-B por fibra. Volatiles porque las escribe
// el hilo Fiber_Rx y las leen el hilo web y el historial.

volatile float    g_temp_remota = 0.0f;   // Ultima temperatura del LM75A (B)
volatile uint32_t g_temp_count  = 0;      // Contador de tramas T: recibidas
volatile uint16_t g_consumo_mA  = 0;      // Corriente activa medida en B
volatile uint16_t g_bateria_mV  = 0;      // Tension del pack de pilas
volatile uint32_t g_pm_count    = 0;      // Contador de tramas P: recibidas
volatile uint16_t g_stop_mA     = 0;      // Corriente pre-Stop (aprox Stop Mode)
volatile uint32_t g_ciclos_totales = 0;   // Ciclos completos run+stop de B
volatile uint16_t g_corriente_ac_cA = 0U;  /* === FASE SCT: corriente AC red x100 */

/* === FASE AC: estado de la alarma de banda de corriente AC, recibido de B
 * via tramas AQ:. La web lo usa para pintar el indicador de estado. */
volatile bool g_alarma_ac_activa = false;
volatile char g_alarma_ac_motivo = '-';   /* 'A'=alta, 'B'=baja, '-'=inactiva */

/* === FASE FIBRA - Watchdog === Tick RTOS de la ultima trama valida recibida.
   La web lo usa para detectar perdida de comunicacion con NUCLEO-B */
volatile uint32_t g_ultimo_rx_fibra_tick = 0;

//ADC_HandleTypeDef adchandle;              // Handle ADC1 de NUCLEO-A (no de B)

uint8_t modo_leds = 0;                    // 0=manual web, 1=carrusel, 2=alarma
char lcd_text[2][20+1] = { "LCD line 1",  // Valores por defecto antes
                           "LCD line 2" };// de cargar config de flash

/* ============================ THREAD IDs ============================ */
// IDs de todos los hilos creados con osThreadNew.
// Se usan como destinatarios de osThreadFlagsSet desde otros hilos/callbacks.
osThreadId_t TID_Display;     // LCD
osThreadId_t TID_Led;         // LEDs (carrusel/alarma)
osThreadId_t TID_Rtc;         // RTC -> strings de hora/fecha
osThreadId_t TID_LDR_5;       // Parpadeo 5Hz tras sync SNTP
osThreadId_t TID_Sntp;        // Cliente SNTP
osThreadId_t TID_Alarma;      // Parpadeo verde 5s al saltar alarma RTC
osThreadId_t TID_LPWR;        // (no se usa en A, A no duerme)
osThreadId_t TID_VIVO;        // Heartbeat LED rojo (sistema vivo)
osThreadId_t TID_TEMP;        // (no se usa en A, temperatura viene por fibra)
osThreadId_t TID_TEST1;       // Test antiguo
osThreadId_t TID_FIBER_TX;    // TX por fibra (comentado, A no envia periodico)
osThreadId_t TID_FIBER_RX;    // RX por fibra (recibe telemetria de B)


/* ============================ DECLARACIONES DE HILOS ============================ */
static void BlinkLed (void *arg);
static void Display  (void *arg);
static void CLKRTC   (void *arg);
static void Sntp     (void *arg);
static void Alarma_RTC(void *arg);
static void LPWR_Mode(void *arg);
static void VIVO     (void *arg);
static void TestFiberA(void *arg);
static void Fiber_Tx_Thread(void *arg);
static void Fiber_Rx_Thread(void *arg);

__NO_RETURN void app_main (void *arg);   // Hilo main (no retorna nunca)


/* ============================ FUNCIONES PARA LA WEB ============================ */

// Lectura de boton expuesta a la web. Devuelve 0 fijo:
// los botones reales (azul) se gestionan por EXTI, no por polling web.
uint8_t get_button (void) {
    return 0;
}

// Callback DHCP: salta cuando la red asigna IP nueva a NUCLEO-A.
// Despierta al hilo Display para que repinte el LCD con la nueva IP.
void netDHCP_Notify (uint32_t if_num, uint8_t option, const uint8_t *val, uint32_t len) {
  (void)if_num; (void)len;

  if (option == NET_DHCP_OPTION_IP_ADDRESS) {
    printf("\r\n[RED] IP asignada: %d.%d.%d.%d", val[0], val[1], val[2], val[3]);
    osThreadFlagsSet (TID_Display, 0x01);
  }

}


/* ============================================================================
   Thread 'Display': gestor del LCD
   Espera flag 0x02 (cambio de lcd_text) y repinta. Se podria refrescar mas
   cuando cambie la IP (flag 0x01 desde netDHCP_Notify), pero aqui solo se
   atiende 0x02. Si quieres que la IP repinte el LCD, anade 0x01 al wait.
============================================================================ */
static __NO_RETURN void Display(void *arg) {
    LCD_reset();                            // Reset hardware del LCD
    Iniciacion_LCD();                       // Configuracion inicial
    reset_buffer();                         // Limpia buffer interno
    (void)arg;

    while(1) {
        osThreadFlagsWait(0x02, osFlagsWaitAny, osWaitForever);  // Espera senal
        reset_buffer();                     // Borra contenido previo
        escribe(lcd_text[0], lcd_text[1]);  // Escribe las 2 lineas
        LCD_update();                       // Vuelca buffer al LCD
    }
}


/* ============================================================================
   Thread 'BlinkLed': controla los LEDs segun el modo activo.
   modo_leds lo cambia la web:
     0 = manual (web controla LEDs uno a uno)
     1 = carrusel "running lights"
     2 = alarma (todos parpadeando a 5 Hz)
============================================================================ */
static __NO_RETURN void BlinkLed (void *arg) {
    // Patron del carrusel: 16 frames con 2 LEDs encendidos en cada uno.
    const uint8_t led_val[16] = { 0x48,0x88,0x84,0x44,0x42,0x22,0x21,0x11,
                                  0x12,0x0A,0x0C,0x14,0x18,0x28,0x30,0x50 };
    uint32_t cnt = 0U;
    bool estado_alarma = false;     // Toggle para parpadeo de alarma
    (void)arg;

    while(1) {
        if (modo_leds == 1) {
            // === Modo carrusel ===
            LED_Expo(led_val[cnt]);              // Aplica patron
            if (++cnt >= sizeof(led_val)) cnt = 0U;
            osDelay(100);                        // 10 frames/s
        }
        else if (modo_leds == 2) {
            // === Modo ALARMA: 5 Hz, todos ON/OFF ===
            estado_alarma = !estado_alarma;
            if (estado_alarma) LED_Expo(0xFF);   // Todos los LEDs ON
            else               LED_Expo(0x00);   // Todos los LEDs OFF
            osDelay(100);                        // 100 ms -> 5 Hz aprox
        }
        else {
            // === Modo manual: la web controla los LEDs ===
            osDelay(100);                        // Solo cede CPU
        }
    }
}


/* ============================================================================
   Thread 'CLKRTC': mantiene actualizados los strings aShowTime / aShowDate
   que consume la web (SSI) y el historial para timestamping.
   Refresco cada 100 ms.
============================================================================ */
static void CLKRTC (void *arg) {
    RTC_Init();                     // Inicializa periferico RTC
    while(1) {
        RTC_WEB(aShowTime, aShowDate);   // Vuelca hora/fecha a strings
				snprintf(aShowStamp, sizeof(aShowStamp), "%s %s", aShowDate, aShowTime);
        osDelay(100);
    }
}


/* ============================================================================
   Thread 'Alarma_RTC': dispara cuando salta la alarma del RTC.
   Lo despierta otro modulo con osThreadFlagsSet(TID_Alarma, 0x04).
   Hace parpadear el LED 0 (verde) durante ~5 segundos.
============================================================================ */
static void Alarma_RTC (void *arg) {
    while (1) {
        osThreadFlagsWait(0x04, osFlagsWaitAny, osWaitForever);

        // 10 iteraciones x ~350 ms = ~3.5 s de parpadeo
        // (los comentarios originales decian 5 s pero no salen las cuentas)
        for(int i = 0; i < 10; i++) {
            LED_Encendido(0);    osDelay(100);
            LED_Apagado(0);      osDelay(250);
        }
    }
}


/* ============================================================================
   Thread 'Sntp': cliente SNTP.
   Espera 5 s al arranque (a que la red este lista), pide hora, vuelca al RTC
   via callback time_callback y resincroniza cada 3 minutos.
============================================================================ */
static __NO_RETURN void Sntp (void *arg) {
    (void)arg;
    osDelay(5000);                        // Espera red lista (DHCP, etc.)
	  printf("Intentando pedir la hora al servidor de Google...\r\n");
    while(1) {
        netSNTPc_GetTime(NULL, time_callback);  // Peticion SNTP -> callback
        osDelay(180000);                  // Resync cada 3 minutos
    }
}


/* ============================================================================
   Thread 'LDR_5': parpadeo de confirmacion de sincronizacion SNTP.
   Cuando time_callback recibe la hora valida, hace
   osThreadFlagsSet(TID_LDR_5, 0x08) y aqui parpadea el LED 2 a 5 Hz
   durante 4 segundos (20 ciclos x 200 ms).
============================================================================ */
static void LDR_5 (void *arg) {
    (void)arg;
    static int ntp_logueado = 0;   /* FASE HIST-v4: registrar la 1a sync NTP */
    while(1) {
        osThreadFlagsWait(0x08, osFlagsWaitAny, osWaitForever);
        if (!ntp_logueado) {
            ntp_logueado = 1;
            Guardar_En_Historial("INFO", aShowStamp, "Hora sincronizada por NTP");
        }
        for (int i = 0; i < 20; i++) {   // 5 Hz durante 4 s
            LED_Encendido(2);  osDelay(100);
            LED_Apagado(2);    osDelay(100);
        }
    }
}


/* ============================================================================
   Thread 'VIVO': heartbeat. NUCLEO-A no duerme, asi que parpadea el LED 0
   a 5 Hz de forma continua para indicar "sistema vivo" en laboratorio.
============================================================================ */
static void VIVO (void *arg) {
    (void)arg;
    /* FASE HIST-v4: vigilancia del enlace de fibra. Cada ~5 s comprueba si
       han pasado >130 s sin trama de B y registra el cambio de estado.
       Arranca en 'caido' para no generar un falso "perdido" antes de la
       primera trama; la primera trama valida produce "Enlace recuperado". */
    static uint32_t vivo_cnt     = 0;
    static int      enlace_caido = 1;
    while(1) {
        LED_Encendido(0);  osDelay(100);
        LED_Apagado(0);    osDelay(100);

        if (++vivo_cnt >= 25U) {           /* 25 x 200 ms ~= 5 s */
            vivo_cnt = 0;
            uint32_t silencio = osKernelGetTickCount() - g_ultimo_rx_fibra_tick;
            if (silencio >= 130000U) {
                if (!enlace_caido) {
                    enlace_caido = 1;
                    Guardar_En_Historial("FIBRA", aShowStamp,
                                         "Enlace perdido (sin tramas de B)");
                }
            } else if (enlace_caido) {
                enlace_caido = 0;
                Guardar_En_Historial("FIBRA", aShowStamp, "Enlace recuperado");
            }
        }
    }
}


/* ============================================================================
   parsear_uid_8hex
   Convierte un string de 8 caracteres hex ("AABBCCDD") en un array de 4 bytes.
   Devuelve 1 si OK, 0 si formato invalido.
   Se usa al recibir "U:AABBCCDD" por fibra para extraer el UID de la tarjeta.
============================================================================ */
static int parsear_uid_8hex(const char *s, uint8_t uid_out[4]) {
    int i;
    if (strlen(s) < 8) return 0;        // Validacion de longitud

    for (i = 0; i < 4; i++) {
        unsigned int byte;
        char tmp[3] = { s[i*2], s[i*2 + 1], '\0' };  // Toma 2 chars hex

        if (sscanf(tmp, "%x", &byte) != 1) return 0; // Convierte a numero
        uid_out[i] = (uint8_t)byte;
    }
    return 1;
}


/*============================================================================
   Fiber_Rx_Thread: parser de las tramas que llegan por fibra desde NUCLEO-B.
   Ensambla bytes hasta '\n' y procesa la linea completa.

   Mensajes soportados (B -> A):
     T:23.5\n          -> temperatura LM75A
     U:AABBCCDD\n      -> UID leido por RFID en B
     P:<mA>,<mV>\n     -> consumo activo + tension de pilas
     S:<mA>\n          -> corriente pre-Stop
     Q:<cA>\n          -> corriente AC red (SCT-013)
     AT:1,28.5\n       -> alarma temperatura ACTIVADA (temp actual)
     AT:0,26.0\n       -> alarma temperatura DESACTIVADA
     AC:1,450\n        -> alarma corriente ACTIVADA (corriente actual)
     AC:0,0\n          -> alarma corriente DESACTIVADA
     AQ:1,A,0\n        -> alarma corriente AC ACTIVADA, motivo ALTA (FASE AC)
     AQ:1,B,0\n        -> alarma corriente AC ACTIVADA, motivo BAJA (FASE AC)
     AQ:0,-,0\n        -> alarma corriente AC DESACTIVADA (FASE AC)

   Mensajes soportados (B -> A, peticiones):
     ?H\n              -> B pide umbral de temperatura
     ?C\n              -> B pide umbral de corriente
     ?M\n              -> B pide modo de ciclo
     ?D\n              -> B pide banda de corriente AC (FASE AC)
============================================================================*/
static void Fiber_Rx_Thread(void *arg) {
    (void)arg;
    static char linea[64];
    uint32_t idx = 0;

    while (1) {
        uint8_t b = Fiber_Read();   /* bloquea hasta que llegue un byte */

        if (b == '\n' || b == '\r') {
            if (idx > 0) {
                linea[idx] = '\0';

                printf("[A] RX cruda: '%s' (len=%u)\r\n", linea, (unsigned)idx);

                uint32_t i = 0;
                while (i < idx) {
                    if (i + 1 >= idx) break;

                    /* ---- T: temperatura ---- */
                    if (linea[i] == 'T' && linea[i+1] == ':') {
                        char num[12]; int j = 0;
                        i += 2;
                        while (i < idx && j < 11) {
                            char x = linea[i];
                            if (x == 'T' || x == 'U' || x == 'P' ||
                                x == 'S' || x == 'A' || x == 'Q' || x == '?') break;
                            if ((x >= '0' && x <= '9') || x == '.' || x == '-')
                                num[j++] = x;
                            i++;
                        }
                        num[j] = '\0';
                        if (j > 0) {
                            float t = (float)atof(num);
                            g_temp_remota = t;
                            g_temp_count++;
                            g_ultimo_rx_fibra_tick = osKernelGetTickCount();
                            printf("[A] Temp: %.1f C (n=%lu)\r\n",
                                   t, (unsigned long)g_temp_count);
                        }
                    }

                    /* ---- U: UID RFID desde B ---- */
                    else if (linea[i] == 'U' && linea[i+1] == ':') {
                        char hex[16]; int j = 0;
                        i += 2;
                        while (i < idx && j < 8) {
                            char x = linea[i];
                            /* NO incluir 'A'-'F': son digitos hex validos del UID.
                             * Solo rompemos en marcas de inicio de trama que no
                             * pueden aparecer dentro de un UID hex. SIN 'A', SIN 'Q'. */
                            if (x == 'T' || x == 'U' || x == 'P' ||
                                x == 'S' || x == '?') break;
                            if ((x >= '0' && x <= '9') ||
                                (x >= 'A' && x <= 'F') ||
                                (x >= 'a' && x <= 'f'))
                                hex[j++] = x;
                            i++;
                        }
                        hex[j] = '\0';
                        if (j == 8) {
                            uint8_t uid[4];
                            if (parsear_uid_8hex(hex, uid)) {
                                printf("[A] UID: %02X:%02X:%02X:%02X\r\n",
                                       uid[0], uid[1], uid[2], uid[3]);
                                Acceso_Maestro_Procesar_UID(uid);
                                g_ultimo_rx_fibra_tick = osKernelGetTickCount();
                            }
                        }
                    }

                    /* ---- P: consumo activo (mA) + tension bateria (mV) ---- */
                    else if (linea[i] == 'P' && linea[i+1] == ':') {
                        char num_i[8], num_v[8];
                        int ji = 0, jv = 0, en_voltaje = 0;
                        i += 2;
                        while (i < idx && ji < 7 && jv < 7) {
                            char x = linea[i];
                            if (x == 'T' || x == 'U' || x == 'P' ||
                                x == 'S' || x == 'A' || x == 'Q' || x == '?') break;
                            if (x == ',')
                                en_voltaje = 1;
                            else if (x >= '0' && x <= '9') {
                                if (!en_voltaje) num_i[ji++] = x;
                                else             num_v[jv++] = x;
                            }
                            i++;
                        }
                        num_i[ji] = '\0';
                        num_v[jv] = '\0';
                        if (ji > 0 && jv > 0) {
                            int i_mA = atoi(num_i);
                            int v_mV = atoi(num_v);
                            if (i_mA >= 0 && i_mA < 2000 &&
                                v_mV >= 0 && v_mV < 10000) {
                                g_consumo_mA = (uint16_t)i_mA;
                                g_bateria_mV = (uint16_t)v_mV;
                                g_pm_count++;
                                {
                                    static int bat_baja = 0;
                                    if (!bat_baja && v_mV > 0 && v_mV < 4400) {
                                        bat_baja = 1;
                                        char mb[48];
                                        snprintf(mb, sizeof(mb), "Bateria baja: %d.%02d V",
                                                 v_mV / 1000, (v_mV % 1000) / 10);
                                        Guardar_En_Historial("AVISO", aShowStamp, mb);
                                    } else if (bat_baja && v_mV >= 4600) {
                                        bat_baja = 0;
                                        Guardar_En_Historial("INFO", aShowStamp,
                                                             "Bateria recuperada");
                                    }
                                }
                                g_ultimo_rx_fibra_tick = osKernelGetTickCount();
                                Corriente_Agregar_Muestra((uint16_t)i_mA);
                                printf("[A] Consumo: %d mA, Vbat: %d mV (n=%lu)\r\n",
                                       i_mA, v_mV, (unsigned long)g_pm_count);
                            }
                        }
                    }

                    /* ---- S: corriente pre-Stop ---- */
                    else if (linea[i] == 'S' && linea[i+1] == ':') {
                        char num[8]; int j = 0;
                        i += 2;
                        while (i < idx && j < 7) {
                            char x = linea[i];
                            if (x == 'T' || x == 'U' || x == 'P' ||
                                x == 'S' || x == 'A' || x == 'Q' || x == '?') break;
                            if (x >= '0' && x <= '9') num[j++] = x;
                            i++;
                        }
                        num[j] = '\0';
                        if (j > 0) {
                            int s_mA = atoi(num);
                            if (s_mA >= 0 && s_mA < 500) {
                                g_stop_mA = (uint16_t)s_mA;
                                g_ciclos_totales++;
                                g_ultimo_rx_fibra_tick = osKernelGetTickCount();
                                printf("[A] Stop Mode: %d mA (ciclo #%lu)\r\n",
                                       s_mA, (unsigned long)g_ciclos_totales);
                                if ((g_ciclos_totales % 5) == 0) {
                                    char msg_hist[64];
                                    snprintf(msg_hist, sizeof(msg_hist),
                                             "I_act=%umA I_stop=%umA V=%u.%02uV",
                                             (unsigned)g_consumo_mA,
                                             (unsigned)g_stop_mA,
                                             (unsigned)(g_bateria_mV / 1000),
                                             (unsigned)((g_bateria_mV % 1000) / 10));
                                    Guardar_En_Historial("PWR", aShowStamp, msg_hist);
                                }
                            }
                        }
                    }

                    /* ---- Q: corriente AC red SCT-013-005 (FASE SCT) ---- */
                    else if (linea[i] == 'Q' && linea[i+1] == ':') {
                        char num[8]; int j = 0;
                        i += 2;
                        while (i < idx && j < 7) {
                            char x = linea[i];
                            if (x == 'T' || x == 'U' || x == 'P' ||
                                x == 'S' || x == 'A' || x == 'Q' || x == '?') break;
                            if (x >= '0' && x <= '9') num[j++] = x;
                            i++;
                        }
                        num[j] = '\0';
                        if (j > 0) {
                            int cA = atoi(num);
                            if (cA >= 0 && cA < 10000) {   /* sanidad: 0..99.99 A */
                                g_corriente_ac_cA = (uint16_t)cA;
                                g_ultimo_rx_fibra_tick = osKernelGetTickCount();
                                printf("[A] SCT: %d cA (%.2f A)\r\n",
                                       cA, cA / 100.0f);
                            }
                        }
                    }

                    /* ---- A: alarmas desde B (AT: temp, AC: corriente DC, AQ: corriente AC) ----
                     * OJO: hay que distinguir "AC:" (corriente DC) de "AQ:" (corriente
                     * AC, FASE AC). Se mira linea[i+1] para decidir cual de los tres es. */
                    else if (linea[i] == 'A' && i + 1 < idx &&
                             (linea[i+1] == 'T' || linea[i+1] == 'C' || linea[i+1] == 'Q')) {
                        char tipo = linea[i+1];
                        i += 2;
                        if (i < idx && linea[i] == ':') i++;
                        char estado = (i < idx) ? linea[i++] : '0';
                        if (i < idx && linea[i] == ',') i++;

                        /* ---- FASE AC: AQ:<estado>,<motivo>,<valor> tiene un
                         * campo extra (el motivo, 'A'/'B'/'-') antes del valor
                         * numerico. Los otros dos (AT/AC) van directo al numero. */
                        char motivo_ac = '-';
                        if (tipo == 'Q') {
                            if (i < idx) motivo_ac = linea[i++];
                            if (i < idx && linea[i] == ',') i++;
                        }

                        char num[12]; int j = 0;
                        while (i < idx && j < 11) {
                            char x = linea[i];
                            if (x == 'T' || x == 'U' || x == 'P' ||
                                x == 'S' || x == 'A' || x == 'Q' || x == '?') break;
                            if ((x >= '0' && x <= '9') || x == '.') num[j++] = x;
                            i++;
                        }
                        num[j] = '\0';

                        if (tipo == 'T') {
                            if (estado == '1') {
                                char msg[56];
                                snprintf(msg, sizeof(msg),
                                         "Temp %.1f C supera umbral %u C",
                                         (double)atof(num),
                                         (unsigned)g_umbral_temp_c);
                                Guardar_En_Historial("ALARMA", aShowStamp, msg);
                                printf("[A] ALARMA TEMP: %s\r\n", msg);
                            } else {
                                Guardar_En_Historial("INFO", aShowStamp,
                                    "Alarma temperatura desactivada");
                                printf("[A] Alarma temp desactivada\r\n");
                            }
                        }
                        else if (tipo == 'C') {
                            if (estado == '1') {
                                char msg[56];
                                snprintf(msg, sizeof(msg),
                                         "Corriente %s mA supera umbral %u mA",
                                         num,
                                         (unsigned)g_umbral_corriente_mA);
                                Guardar_En_Historial("ALARMA", aShowStamp, msg);
                                printf("[A] ALARMA CORRIENTE: %s\r\n", msg);
                            } else {
                                Guardar_En_Historial("INFO", aShowStamp,
                                    "Alarma corriente desactivada");
                                printf("[A] Alarma corriente desactivada\r\n");
                            }
                        }
                        else { /* tipo == 'Q' : FASE AC, corriente AC fuera de banda */
                            g_alarma_ac_motivo = motivo_ac;
                            if (estado == '1') {
                                g_alarma_ac_activa = true;
                                const char *motivo_txt =
                                    (motivo_ac == 'A') ? "ALTA" :
                                    (motivo_ac == 'B') ? "BAJA" : "?";
                                char msg[72];
                                snprintf(msg, sizeof(msg),
                                         "Corriente AC fuera de banda (%s): %.2f..%.2f A",
                                         motivo_txt,
                                         g_umbral_ac_bajo_cA / 100.0f,
                                         g_umbral_ac_alto_cA / 100.0f);
                                Guardar_En_Historial("ALARMA", aShowStamp, msg);
                                printf("[A] ALARMA CORRIENTE AC: %s\r\n", msg);
                            } else {
                                g_alarma_ac_activa = false;
                                Guardar_En_Historial("INFO", aShowStamp,
                                    "Alarma corriente AC desactivada");
                                printf("[A] Alarma corriente AC desactivada\r\n");
                            }
                        }
                    }

                    /* ---- ?: peticiones de umbral desde B ---- */
                    else if (linea[i] == '?' && i + 1 < idx) {
                        char cmd = linea[i+1];
                        i += 2;
                        if (cmd == 'H') {
                            printf("[A] B pide umbral temp, enviando %u C\r\n",
                                   (unsigned)g_umbral_temp_c);
                            Fiber_Enviar_Umbral_Temp(g_umbral_temp_c);
                        }
                        else if (cmd == 'C') {
                            printf("[A] B pide umbral corriente, enviando %u mA\r\n",
                                   (unsigned)g_umbral_corriente_mA);
                            Fiber_Enviar_Umbral_Corriente(g_umbral_corriente_mA);
                        }
                        else if (cmd == 'M') {
                            printf("[A] B pide modo ciclo, enviando %u\r\n",
                                   (unsigned)g_tasa_refresco_seg);
                            Fiber_Enviar_Modo((uint8_t)g_tasa_refresco_seg);
                        }
                        /* ---- FASE AC: B pide banda de corriente AC ---- */
                        else if (cmd == 'D') {
                            printf("[A] B pide banda AC, enviando %u..%u cA\r\n",
                                   (unsigned)g_umbral_ac_bajo_cA,
                                   (unsigned)g_umbral_ac_alto_cA);
                            Fiber_Enviar_Umbrales_AC(g_umbral_ac_bajo_cA,
                                                      g_umbral_ac_alto_cA);
                        }
                    }

                    else {
                        i++;   /* byte no reconocido -> descarta */
                    }
                }
            }
            idx = 0;
        }
        else if (idx < 63) {
            if (b >= 32 && b < 127) linea[idx++] = b;
        }
        else {
            idx = 0;   /* overflow -> descarta linea */
        }
    }
}

/* ============================================================================
   app_main: hilo principal de la aplicacion.
   Inicializa perifericos, modulos, red y lanza todos los hilos.
   Termina con osThreadExit() (libera su stack, ya no se necesita).
============================================================================ */
__NO_RETURN void app_main (void *arg) {
    (void)arg;

    // Colas de mensajes para que la web pueda escribir en el LCD
    colaLCD_L1 = osMessageQueueNew(5, 20*sizeof(char), NULL);
    colaLCD_L2 = osMessageQueueNew(5, 20*sizeof(char), NULL);

    // --- Inicializacion de perifericos basicos ---
    BotonAzul_Init();                       // EXTI del boton azul (PC13)
    LED_Init();                             // GPIOs de los LEDs

    // --- Memoria externa, historial y configuracion ---
    Memoria_Init();                         // Init driver W25Q128 (SPI)
    printf("=== Arranque del sistema ===\r\n");
    Config_Cargar();                        // Lee config persistente de flash

    // === SENTINEL E ===
    // Sincroniza el LCD con la config recien cargada de flash, asi al
    // reiniciar la placa el LCD muestra ID/Ubicacion guardados en vez
    // de los placeholders "LCD line 1" / "LCD line 2".
    strncpy(lcd_text[0], g_id_dispositivo, 20);  lcd_text[0][20] = '\0';
    strncpy(lcd_text[1], g_ubicacion,      20);  lcd_text[1][20] = '\0';

    Init_Thread_Historial();                // Lanza hilo de gestion del log

    // Modulo de acceso maestro: gestiona desbloqueo de la web cuando llega
    // por fibra el UID de la tarjeta maestra leida en NUCLEO-B
    Acceso_Maestro_Init();

    // --- RFID local DESHABILITADO ---
    // El RFID se ha movido a NUCLEO-B; se accede via fibra (mensajes U:)
    //Aplicacion_RFID_Inicializar();
    //Aplicacion_RFID_Crear_Tarea();

    // --- Enlace por fibra optica ---
    Fiber_Init();                                   // Init USART2 (fibra)
    osDelay(2000);                                  // Da tiempo a B a arrancar
    Fiber_Enviar_Umbral_Temp(g_umbral_temp_c);      // Empuja umbral inicial a B
		Fiber_Enviar_Umbral_Corriente(g_umbral_corriente_mA); 
		Fiber_Enviar_Modo((uint8_t)g_tasa_refresco_seg);
		Fiber_Enviar_Umbrales_AC(g_umbral_ac_bajo_cA, g_umbral_ac_alto_cA);  /* FASE AC */
    // --- Red (HTTP, SNTP, DHCP...) ---
    netInitialize();                                // Stack TCP/IP

    // --- Lanzamiento de hilos de aplicacion ---
    TID_Led     = osThreadNew(BlinkLed,        NULL, NULL);
    TID_Display = osThreadNew(Display,         NULL, NULL);
    TID_Rtc     = osThreadNew(CLKRTC,          NULL, NULL);
    TID_LDR_5   = osThreadNew(LDR_5,           NULL, NULL);
    TID_Sntp    = osThreadNew(Sntp,            NULL, NULL);
    TID_Alarma  = osThreadNew(Alarma_RTC,      NULL, NULL);
    TID_VIVO    = osThreadNew(VIVO,            NULL, NULL);

    // Hilo TX de fibra DESACTIVADO: A solo envia bajo demanda
    // (umbrales, comandos), no en bucle.
    //TID_FIBER_TX = osThreadNew(Fiber_Tx_Thread, NULL, &fiber_tx_attr);
    TID_FIBER_RX = osThreadNew(Fiber_Rx_Thread, NULL, &fiber_rx_attr);

    // Espera a que la hora sea coherente y registra evento de arranque
    osDelay(5000);
    Guardar_En_Historial("INFO", aShowStamp , "Sistema arrancado");
    osThreadExit();             // Libera el stack de app_main (2 KB)
}


/* ============================================================================
   Redireccion de printf hacia ITM/SWO.
   Cada char escrito con printf se envia por SWO y aparece en el ITM Viewer
   de Keil. NUCLEO-A todavia depende del ST-LINK para esto.
============================================================================ */
struct __FILE { int handle; };
FILE __stdout;
FILE __stdin;

int fputc(int ch, FILE *f) {
    return (ITM_SendChar(ch));      // Envia caracter por SWO
}