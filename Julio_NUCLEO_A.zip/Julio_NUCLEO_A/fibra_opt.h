#ifndef FIBRA_OPT_H
#define FIBRA_OPT_H

#include <stdint.h>

/* Inicializa USART2 a 115200, TX y RX */
void Fiber_Init(void);

/* Envia un texto por la fibra */
void Fiber_Send(char *texto);

/* Lee un byte recibido. Devuelve 0 si no hay nada. */
uint8_t Fiber_Read(void);

int Fibra_Cable_Conectado(void);
/* Envia el umbral de temperatura a NUCLEO-B.
 * Formato: "U:<temp>\n" donde <temp> es un entero en grados C.
 * Llamar tras cambiar g_umbral_temp_c. */
void Fiber_Enviar_Umbral_Temp(uint16_t temp_c);

void Fiber_Enviar_Umbral_Corriente(uint16_t corriente_mA);

void Fiber_Enviar_Modo(uint8_t modo);

/* === FASE AC: envia a NUCLEO-B la banda de corriente AC (SCT-013).
 * Formato de trama: "D:<bajo_cA>,<alto_cA>\n"  (ej: "D:60,170\n")
 * Llamar al arranque (app_main) y cada vez que el usuario modifica
 * los umbrales desde config.cgi. Unidad: centiamperios (cA). */
void Fiber_Enviar_Umbrales_AC(uint16_t bajo_cA, uint16_t alto_cA);


#endif