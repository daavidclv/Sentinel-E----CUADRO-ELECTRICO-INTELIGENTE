/* ============================================================================
 * FASE SCT � alarma_corriente_ac.c
 * Motor de alarma de corriente ALTERNA (red, SCT-013-005).
 *
 * Vigila la banda [umbral_bajo, umbral_alto] en cA. Fuera de banda por
 * arriba o por abajo dispara la misma alarma (sonido+LEDs), reportando el
 * motivo a A para el historial.
 * ========================================================================== */
#include "alarma_corriente_ac.h"
#include "alarma_pwm.h"       /* driver PWM compartido con alarma_motor/corriente */
#include "cmsis_os2.h"
#include "LEDs.h"
#include <stdio.h>

/* ---- Flags internos del thread de alarma de corriente AC ---- */
#define FLAG_AC_ACTIVATE_ALTA   (1U << 0)
#define FLAG_AC_ACTIVATE_BAJA   (1U << 1)
#define FLAG_AC_DEACTIVATE      (1U << 2)
#define FLAG_AC_BEEP_TICK       (1U << 3)   /* tick del patron doble-beep */
#define FLAG_AC_LED_TICK        (1U << 4)   /* tick del parpadeo alterno LEDs */

/* Frecuencia del tono: distinta de temperatura (2000-3500 barrido) y de
 * corriente DC (1500 fijo). Agudo y corto, facil de distinguir. */
#define AC_FREQ_HZ           2800U

/* Patron doble-beep: ON-OFF-ON-OFF-PAUSA, ciclo total 480ms.
 * Se implementa como una secuencia de 4 ticks de 60ms + 1 tick de 300ms,
 * manejados por un unico osTimer reprogramado en cada paso. */
#define AC_BEEP_PULSE_MS       60U
#define AC_BEEP_PAUSE_MS      300U

#define AC_LED_TICK_MS        100U          /* 5 Hz = 100ms por fase */

static osThreadId_t  s_tid_ac        = NULL;
static osTimerId_t   s_tim_beep      = NULL;   /* tick patron beep (periodo variable) */
static osTimerId_t   s_tim_led       = NULL;   /* tick parpadeo LEDs */
static osMutexId_t   s_mtx_state     = NULL;

static volatile bool     s_active        = false;
static volatile alarma_ac_motivo_t s_motivo = ALARMA_AC_MOTIVO_NINGUNO;
static volatile uint8_t  s_beep_paso      = 0;   /* 0..3 = pulso, 4 = pausa */
static volatile bool     s_led_fase       = false;
static volatile uint16_t s_umbral_bajo_cA = ALARMA_AC_UMBRAL_BAJO_DEFAULT_CA;
static volatile uint16_t s_umbral_alto_cA = ALARMA_AC_UMBRAL_ALTO_DEFAULT_CA;

/* Prototipos internos */
static void CorrienteACThread(void *arg);
static void BeepTimerCb(void *arg);
static void LedTimerCb(void *arg);
static void EnviarEventoFibra(bool activa, alarma_ac_motivo_t motivo, uint16_t valor_cA);


/* -------------------------------------------------------------------------- */
int Motor_CorrienteAC_Init(void)
{
    /* El PWM (AlarmaPWM_Init) ya lo inicializa alarma_motor. NO llamar
     * aqui para no reinicializar TIM1 (idempotente de todas formas, pero
     * el orden de init importa para no pisar config a medio escribir). */

    s_mtx_state = osMutexNew(NULL);
    if (s_mtx_state == NULL) return -1;

    s_tim_beep = osTimerNew(BeepTimerCb, osTimerOnce, NULL, NULL);
    if (s_tim_beep == NULL) return -2;

    s_tim_led = osTimerNew(LedTimerCb, osTimerPeriodic, NULL, NULL);
    if (s_tim_led == NULL) return -3;

    const osThreadAttr_t attr = {
        .name       = "CorrienteACThread",
        .stack_size = 512U,
        .priority   = osPriorityAboveNormal,
    };
    s_tid_ac = osThreadNew(CorrienteACThread, NULL, &attr);
    if (s_tid_ac == NULL) return -4;

    return 0;
}

/* -------------------------------------------------------------------------- */
void Motor_CorrienteAC_SetUmbrales(uint16_t umbral_bajo_cA, uint16_t umbral_alto_cA)
{
    /* Saneado basico: bajo siempre por debajo de alto */
    if (umbral_bajo_cA >= umbral_alto_cA) return;

    osMutexAcquire(s_mtx_state, osWaitForever);
    s_umbral_bajo_cA = umbral_bajo_cA;
    s_umbral_alto_cA = umbral_alto_cA;
    osMutexRelease(s_mtx_state);

    printf("[AC] Nueva banda: %u..%u cA\r\n",
           (unsigned)umbral_bajo_cA, (unsigned)umbral_alto_cA);
}

/* -------------------------------------------------------------------------- */
uint16_t Motor_CorrienteAC_GetUmbralBajo(void)
{
    uint16_t v;
    osMutexAcquire(s_mtx_state, osWaitForever);
    v = s_umbral_bajo_cA;
    osMutexRelease(s_mtx_state);
    return v;
}

uint16_t Motor_CorrienteAC_GetUmbralAlto(void)
{
    uint16_t v;
    osMutexAcquire(s_mtx_state, osWaitForever);
    v = s_umbral_alto_cA;
    osMutexRelease(s_mtx_state);
    return v;
}

/* -------------------------------------------------------------------------- */
bool Motor_CorrienteAC_IsActive(void)
{
    return s_active;
}

/* -------------------------------------------------------------------------- */
/* Llamado cada vez que hay nueva lectura de corriente AC.
 * Histeresis: una vez activa, hay que volver a entrar HYSTERESIS_CA dentro
 * de la banda (no solo rozar el umbral) para desactivar. Esto evita
 * parpadeo de alarma si el valor oscila justo en el borde. */
void Motor_CorrienteAC_OnNewMeasurement(uint16_t corriente_ac_cA)
{
    uint16_t bajo, alto;
    osMutexAcquire(s_mtx_state, osWaitForever);
    bajo = s_umbral_bajo_cA;
    alto = s_umbral_alto_cA;
    osMutexRelease(s_mtx_state);

    if (!s_active) {
        if (corriente_ac_cA > alto) {
            printf("[AC] I=%u cA > %u cA -> ACTIVAR (ALTA)\r\n",
                   (unsigned)corriente_ac_cA, (unsigned)alto);
            osThreadFlagsSet(s_tid_ac, FLAG_AC_ACTIVATE_ALTA);
        } else if (corriente_ac_cA < bajo) {
            printf("[AC] I=%u cA < %u cA -> ACTIVAR (BAJA)\r\n",
                   (unsigned)corriente_ac_cA, (unsigned)bajo);
            osThreadFlagsSet(s_tid_ac, FLAG_AC_ACTIVATE_BAJA);
        }
    } else {
        /* Solo desactiva si vuelve a estar HOLGADAMENTE dentro de la banda,
         * sea cual sea el motivo que la disparo (alta o baja). */
        uint16_t margen_bajo = (uint16_t)(bajo + ALARMA_AC_HYSTERESIS_CA);
        uint16_t margen_alto = (uint16_t)(alto - ALARMA_AC_HYSTERESIS_CA);
        if (corriente_ac_cA >= margen_bajo && corriente_ac_cA <= margen_alto) {
            printf("[AC] I=%u cA dentro de banda segura -> DESACTIVAR\r\n",
                   (unsigned)corriente_ac_cA);
            osThreadFlagsSet(s_tid_ac, FLAG_AC_DEACTIVATE);
        }
    }
}

/* -------------------------------------------------------------------------- */
static void EnviarEventoFibra(bool activa, alarma_ac_motivo_t motivo, uint16_t valor_cA)
{
    char buf[32];
    char motivo_ch = '-';
    if (motivo == ALARMA_AC_MOTIVO_ALTA) motivo_ch = 'A';
    else if (motivo == ALARMA_AC_MOTIVO_BAJA) motivo_ch = 'B';

    snprintf(buf, sizeof(buf), "AQ:%u,%c,%u\n",
             activa ? 1U : 0U, motivo_ch, (unsigned)valor_cA);

    extern void Fiber_Send(char *texto);
    Fiber_Send(buf);
}

/* -------------------------------------------------------------------------- */
static void BeepTimerCb(void *arg)
{
    (void)arg;
    osThreadFlagsSet(s_tid_ac, FLAG_AC_BEEP_TICK);
}

static void LedTimerCb(void *arg)
{
    (void)arg;
    osThreadFlagsSet(s_tid_ac, FLAG_AC_LED_TICK);
}

/* -------------------------------------------------------------------------- */
static void CorrienteACThread(void *arg)
{
    (void)arg;

    while (1) {
        uint32_t flags = osThreadFlagsWait(
            FLAG_AC_ACTIVATE_ALTA | FLAG_AC_ACTIVATE_BAJA |
            FLAG_AC_DEACTIVATE | FLAG_AC_BEEP_TICK | FLAG_AC_LED_TICK,
            osFlagsWaitAny, osWaitForever);

        /* --- Activar (por ALTA o por BAJA): mismo arranque, motivo distinto --- */
        if (flags & (FLAG_AC_ACTIVATE_ALTA | FLAG_AC_ACTIVATE_BAJA)) {
            if (!s_active) {
                s_active     = true;
                s_motivo     = (flags & FLAG_AC_ACTIVATE_ALTA) ?
                               ALARMA_AC_MOTIVO_ALTA : ALARMA_AC_MOTIVO_BAJA;
                s_beep_paso  = 0;
                s_led_fase   = false;

                /* Arranca patron: primer pulso ya mismo, timer one-shot
                 * se reprograma solo en cada tick (ver mas abajo). */
                AlarmaPWM_SetFrequency(AC_FREQ_HZ);
                AlarmaPWM_On();
                osTimerStart(s_tim_beep, AC_BEEP_PULSE_MS);

                osTimerStart(s_tim_led, AC_LED_TICK_MS);
                LED_Encendido(0);
                LED_Apagado(1);

                EnviarEventoFibra(true, s_motivo, 0U);
            }
        }

        /* --- Desactivar --- */
        if (flags & FLAG_AC_DEACTIVATE) {
            if (s_active) {
                s_active = false;
                osTimerStop(s_tim_beep);
                osTimerStop(s_tim_led);

                /* Igual que alarma_corriente: apaga PWM. Si hay otra alarma
                 * sonando a la vez, su propio tick lo reactivara en su
                 * siguiente flanco (mismo compromiso ya asumido en el
                 * resto del sistema, un solo buzzer compartido). */
                AlarmaPWM_Off();

                LED_Apagado(0);
                LED_Apagado(1);

                EnviarEventoFibra(false, ALARMA_AC_MOTIVO_NINGUNO, 0U);
                s_motivo = ALARMA_AC_MOTIVO_NINGUNO;
            }
        }

        /* --- Tick del patron doble-beep ---
         * Secuencia (5 pasos, se repite):
         *   paso 0: ON  (pulso 1)      -> dura AC_BEEP_PULSE_MS
         *   paso 1: OFF (entre pulsos) -> dura AC_BEEP_PULSE_MS
         *   paso 2: ON  (pulso 2)      -> dura AC_BEEP_PULSE_MS
         *   paso 3: OFF (fin pulsos)   -> dura AC_BEEP_PULSE_MS
         *   paso 4: OFF (pausa larga)  -> dura AC_BEEP_PAUSE_MS, vuelve a 0
         */
        if ((flags & FLAG_AC_BEEP_TICK) && s_active) {
            uint32_t siguiente_ms;

            switch (s_beep_paso) {
                case 0: AlarmaPWM_On();  siguiente_ms = AC_BEEP_PULSE_MS; break;
                case 1: AlarmaPWM_Off(); siguiente_ms = AC_BEEP_PULSE_MS; break;
                case 2: AlarmaPWM_On();  siguiente_ms = AC_BEEP_PULSE_MS; break;
                case 3: AlarmaPWM_Off(); siguiente_ms = AC_BEEP_PAUSE_MS; break;
                default: AlarmaPWM_Off(); s_beep_paso = 0xFFU;
                         siguiente_ms = AC_BEEP_PULSE_MS; break;
            }
            s_beep_paso = (uint8_t)((s_beep_paso + 1U) % 5U);
            osTimerStart(s_tim_beep, siguiente_ms);
        }

        /* --- Tick del parpadeo alterno LED0/LED1 --- */
        if ((flags & FLAG_AC_LED_TICK) && s_active) {
            s_led_fase = !s_led_fase;
            if (s_led_fase) {
                LED_Encendido(1);
                LED_Apagado(0);
            } else {
                LED_Encendido(0);
                LED_Apagado(1);
            }
        }
    }
}