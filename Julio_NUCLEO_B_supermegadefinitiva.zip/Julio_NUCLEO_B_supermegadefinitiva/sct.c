#include "sct.h"
#include <math.h>

/* ---- Parametros del SCT-013-005 ---- */
#define CANAL_SCT       10U      /* ADC1_IN10 -> PC0 (igual que tu ejemplo) */
#define SENS_SCT        5.0f     /* 5 A RMS por cada 1 V RMS de salida      */
#define CAL             1.00f    /* ajuste fino tras comparar con pinza     */
#define VREF_BIAS       1.65f    /* offset DC teorico (Vref/2)              */
#define T_VENTANA_MS    200U     /* ventana de medida (~10 ciclos a 50 Hz)  */
#define UMBRAL_RUIDO    0.08f    /* por debajo de esto -> 0 A (banda muerta)*/
#define DELTA_PUBLICA   0.05f    /* publica solo si cambia >= 50 mA         */

osThreadId_t       tid_ThCorriente;
osMessageQueueId_t id_MsgCorrQueue;

/* === FASE SCT: ultima lectura de corriente AC, en Amperios RMS.
 * Variable GLOBAL del modulo (no local a ThCorriente): app_main.c la lee
 * via "extern volatile float g_Irms_sct;" para construir la trama Q:<cA>.
 * Si se declara dentro de ThCorriente() pasa a ser una variable de bloque
 * sin enlace externo -> "Undefined symbol g_Irms_sct" en el linker. */
volatile float g_Irms_sct = 0.0f;

static __NO_RETURN void ThCorriente(void *argument);

/* offset DC: se autoajusta con un filtro paso-alto (estilo EmonLib).
   Arranca en 1.65 V para que converja rapido. */
static float offset = VREF_BIAS;

/* Mide la corriente RMS muestreando el ADC durante T_VENTANA_MS */
static float medir_Irms(ADC_HandleTypeDef *hadc) {
    double   sumaCuadrados = 0.0;
    uint32_t n  = 0U;
    uint32_t t0 = osKernelGetTickCount();        /* tick en ms */

    while ((osKernelGetTickCount() - t0) < T_VENTANA_MS) {
        float v = ADC_read_voltage_fast(hadc);   /* tension instantanea  */
        offset += (v - offset) / 1024.0f;        /* sigue la continua    */
        float vac = v - offset;                  /* componente alterna   */
        sumaCuadrados += (double)vac * (double)vac;       /* acumula el cuadrado  */
        n++;
    }
    if (n == 0U) return 0.0f;

    float vrms = sqrtf((float)(sumaCuadrados / n));  /* tension RMS salida */
    float irms = vrms * SENS_SCT * CAL;              /* 1 V -> 5 A         */
    if (irms < UMBRAL_RUIDO) irms = 0.0f;            /* banda muerta       */
    return irms;
}

int Init_ThCorriente(void) {
    id_MsgCorrQueue = osMessageQueueNew(8, sizeof(messageCORR_t), NULL);
    if (id_MsgCorrQueue == NULL) return -1;

    tid_ThCorriente = osThreadNew(ThCorriente, NULL, NULL);
    if (tid_ThCorriente == NULL) return -1;
    return 0;
}

static __NO_RETURN void ThCorriente(void *argument) {
    (void)argument;
    ADC_HandleTypeDef adchandle;
    messageCORR_t     msg;
    float ultima = -1.0f;

    ADC1_pins_F429ZI_config();                    /* PC0 como analogico  */
    ADC_Init_Single_Conversion(&adchandle, ADC1); /* ADC1, 12 bits       */
    ADC_config_channel(&adchandle, CANAL_SCT);    /* canal UNA sola vez  */

    (void)medir_Irms(&adchandle);   /* descarte: deja converger el offset */
    for (;;) {
        msg.irms     = medir_Irms(&adchandle);
        msg.potencia = 230.0f * msg.irms;         /* asume 230 V, FP=1   */
        g_Irms_sct   = msg.irms;
        /* publica solo si cambia, para no saturar la cola */
        if (fabsf(msg.irms - ultima) >= DELTA_PUBLICA) {
            osMessageQueuePut(id_MsgCorrQueue, &msg, NULL, 0U);
            ultima = msg.irms;
        }
        osDelay(500);
        osThreadYield();
    }
}