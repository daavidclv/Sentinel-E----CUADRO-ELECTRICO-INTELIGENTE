#include "ThTestCorriente.h"

osThreadId_t tid_ThTestPot;

/* Variables para ver en el Watch */
float    g_PotIrms     = 0.0f;
float    g_PotPotencia = 0.0f;
uint32_t g_PotCount    = 0U;

static __NO_RETURN void ThTestPot (void *argument);

int Init_ThTestPot (void) {
    Init_ThCorriente();
    tid_ThTestPot = osThreadNew(ThTestPot, NULL, NULL);
    if (tid_ThTestPot == NULL) {
        return -1;
    }
    return 0;
}

static __NO_RETURN void ThTestPot (void *argument) {
    (void)argument;
    messageCORR_t msg;

    while (1) {
        /* Espera bloqueante a nuevas muestras del modulo de corriente */
        if (osMessageQueueGet(id_MsgCorrQueue, &msg, NULL, osWaitForever) == osOK) {
            g_PotIrms     = msg.irms;
            g_PotPotencia = msg.potencia;
            g_PotCount++;
        }
    }
}