#ifndef corriente_h
#define corriente_h

#include <stdint.h>

/*-----------------------------------------------------------------------------
 * ina226.h - FASE INA226
 * Driver del sensor de corriente/tension INA226 por I2C3 (PH7=SCL, PH8=SDA).
 * Sustituye al front-end analogico INA180A3 + MCP6001 + ADC de NUCLEO-B.
 * Requiere CMSIS-Driver I2C3 habilitado en el RTE (Driver_I2C3).
 *---------------------------------------------------------------------------*/

/* Inicializa I2C3 y configura el INA226 (config + calibracion).
 * Devuelve 0 si OK, <0 si error (chip no responde, etc). */
int INA226_Init(void);

/* Lee la corriente en mA (>=0). Devuelve 0 si OK. */
int INA226_Read_Current_mA(uint16_t *out_mA);

/* Lee la tension de bus (VBUS) en mV. Devuelve 0 si OK. */
int INA226_Read_BusVoltage_mV(uint16_t *out_mV);

/* Lectura combinada corriente (mA) + tension (mV). Devuelve 0 si OK. */
int INA226_Read(uint16_t *out_mA, uint16_t *out_mV);

#endif /* INA226_H */