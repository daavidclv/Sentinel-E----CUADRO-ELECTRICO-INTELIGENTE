/* ============================================================================
 * FASE G � alarma_corriente.c
 * Motor de alarma de corriente.
 *
 * Patr�n sonoro: beep r�pido fijo a 1500 Hz (100ms ON / 100ms OFF).
 * Difiere de la alarma de temperatura (sirena 2000-3500 Hz) para que
 * el operador pueda distinguir el tipo de alarma por el sonido.
 *
 * LEDs: cuando la alarma de corriente est� activa, todos los LEDs
 * parpadean a 5 Hz (100ms ON / 100ms OFF). Se gestiona desde este
 * m�dulo con un osTimer independiente del thread de alarma.
 * ========================================================================== */
#include "alarma_corriente.h"
#include "alarma_pwm.h"       /* driver PWM compartido con alarma_motor */
#include "cmsis_os2.h"
#include "LEDs.h"
#include <stdio.h>

/* ---- Flags internos del thread de alarma de corriente ---- */
#define FLAG_CORR_ACTIVATE    (1U << 0)
#define FLAG_CORR_DEACTIVATE  (1U << 1)
#define FLAG_CORR_BEEP_TICK   (1U << 2)   /* tick del patr�n beep */
#define FLAG_CORR_LED_TICK    (1U << 3)   /* tick del parpadeo de LEDs */

/* Frecuencia del tono de alarma de corriente (distinto de temperatura) */
#define CORRIENTE_FREQ_HZ     1500U
#define CORRIENTE_BEEP_ON_MS  100U
#define CORRIENTE_BEEP_OFF_MS 100U
#define CORRIENTE_LED_TICK_MS 100U        /* 5 Hz = 100ms ON + 100ms OFF */

static osThreadId_t  s_tid_corriente  = NULL;
static osTimerId_t   s_tim_beep       = NULL;   /* tick beep PWM */
static osTimerId_t   s_tim_led        = NULL;   /* tick parpadeo LEDs */
static osMutexId_t   s_mtx_state      = NULL;

static volatile bool     s_active       = false;
static volatile bool     s_beep_on      = false;  /* estado actual del tono */
static volatile bool     s_led_on       = false;  /* estado actual LEDs */
static volatile uint16_t s_threshold_mA =
    ALARMA_CORRIENTE_THRESHOLD_DEFAULT_MA;

/* Prototipos internos */
static void CorrienteThread(void *arg);
static void BeepTimerCb(void *arg);
static void LedTimerCb(void *arg);


/* -------------------------------------------------------------------------- */
int Motor_Corriente_Init(void)
{
    /* El PWM (AlarmaPWM_Init) ya lo inicializa alarma_motor. NO llamar
     * aqu� para no reinicializar TIM1. Si por alguna raz�n este m�dulo
     * se inicializa antes, descomentar la l�nea siguiente:
     * AlarmaPWM_Init(); AlarmaPWM_Off(); */

    s_mtx_state = osMutexNew(NULL);
    if (s_mtx_state == NULL) return -1;

    /* Timer de beep: alterna ON/OFF cada 100 ms */
    s_tim_beep = osTimerNew(BeepTimerCb, osTimerPeriodic, NULL, NULL);
    if (s_tim_beep == NULL) return -2;

    /* Timer de LEDs: parpadeo a 5 Hz */
    s_tim_led = osTimerNew(LedTimerCb, osTimerPeriodic, NULL, NULL);
    if (s_tim_led == NULL) return -3;

    const osThreadAttr_t attr = {
        .name       = "CorrienteThread",
        .stack_size = 512U,
        .priority   = osPriorityAboveNormal,
    };
    s_tid_corriente = osThreadNew(CorrienteThread, NULL, &attr);
    if (s_tid_corriente == NULL) return -4;

    return 0;
}

/* -------------------------------------------------------------------------- */
void Motor_Corriente_SetThreshold(uint16_t umbral_mA)
{
    osMutexAcquire(s_mtx_state, osWaitForever);
    s_threshold_mA = umbral_mA;
    osMutexRelease(s_mtx_state);

    printf("[CORRIENTE] Nuevo umbral: %u mA\r\n", (unsigned)umbral_mA);
}

/* -------------------------------------------------------------------------- */
uint16_t Motor_Corriente_GetThreshold(void)
{
    uint16_t v;
    osMutexAcquire(s_mtx_state, osWaitForever);
    v = s_threshold_mA;
    osMutexRelease(s_mtx_state);
    return v;
}

/* -------------------------------------------------------------------------- */
bool Motor_Corriente_IsActive(void)
{
    return s_active;
}

/* -------------------------------------------------------------------------- */
/* Llamado desde TEMP en cada ciclo.
 * Hist�resis: activa si supera el umbral, desactiva si baja de umbral-20mA.
 */
void Motor_Corriente_OnNewMeasurement(uint16_t corriente_mA)
{
    uint16_t th;
    osMutexAcquire(s_mtx_state, osWaitForever);
    th = s_threshold_mA;
    osMutexRelease(s_mtx_state);

    if (!s_active) {
        if (corriente_mA > th) {
            printf("[CORRIENTE] I=%u mA > %u mA -> ACTIVAR\r\n",
                   (unsigned)corriente_mA, (unsigned)th);
            osThreadFlagsSet(s_tid_corriente, FLAG_CORR_ACTIVATE);
        }
    } else {
        if (corriente_mA < (uint16_t)(th - ALARMA_CORRIENTE_HYSTERESIS_MA)) {
            printf("[CORRIENTE] I=%u mA < %u mA -> DESACTIVAR\r\n",
                   (unsigned)corriente_mA,
                   (unsigned)(th - ALARMA_CORRIENTE_HYSTERESIS_MA));
            osThreadFlagsSet(s_tid_corriente, FLAG_CORR_DEACTIVATE);
        }
    }
}

/* -------------------------------------------------------------------------- */
static void BeepTimerCb(void *arg)
{
    (void)arg;
    osThreadFlagsSet(s_tid_corriente, FLAG_CORR_BEEP_TICK);
}

static void LedTimerCb(void *arg)
{
    (void)arg;
    osThreadFlagsSet(s_tid_corriente, FLAG_CORR_LED_TICK);
}

/* -------------------------------------------------------------------------- */
static void CorrienteThread(void *arg)
{
    (void)arg;

    while (1) {
        uint32_t flags = osThreadFlagsWait(
            FLAG_CORR_ACTIVATE | FLAG_CORR_DEACTIVATE |
            FLAG_CORR_BEEP_TICK | FLAG_CORR_LED_TICK,
            osFlagsWaitAny, osWaitForever);

        /* --- Activar alarma de corriente --- */
        if (flags & FLAG_CORR_ACTIVATE) {
            if (!s_active) {
                s_active   = true;
                s_beep_on  = false;
                s_led_on   = false;

                /* Arranca timers de beep y LEDs */
                osTimerStart(s_tim_beep, CORRIENTE_BEEP_ON_MS);
                osTimerStart(s_tim_led,  CORRIENTE_LED_TICK_MS);

                /* TODO FASE FIBRA: notificar a A
                 * Fiber_Send("AC:1\n");
                 */
								{
								char buf[16];
								snprintf(buf, sizeof(buf), "AC:1,%u\n",
												 (unsigned)s_threshold_mA);
								extern void Fiber_Send(char *texto);
								Fiber_Send(buf);
								}
            }
        }

        /* --- Desactivar alarma de corriente --- */
        if (flags & FLAG_CORR_DEACTIVATE) {
            if (s_active) {
                s_active = false;
                osTimerStop(s_tim_beep);
                osTimerStop(s_tim_led);

                /* Apagar PWM solo si la alarma de temperatura NO est� activa.
                 * Si est� activa, la sirena de temperatura sigue sonando. */
                /* Motor_Alarma_IsActive() crea dependencia circular; usamos
                 * AlarmaPWM_Off() solo si el PWM estaba en modo beep. */
                AlarmaPWM_Off();

                /* Apagar todos los LEDs (el heartbeat VIVO los retomar�) */
                LED_Apagado(0);
                LED_Apagado(1);
                LED_Apagado(2);

                /* TODO FASE FIBRA: notificar a A
                 * Fiber_Send("AC:0\n");
                 */
								{
								char buf[16];
								snprintf(buf, sizeof(buf), "AC:0,0\n");
								extern void Fiber_Send(char *texto);
								Fiber_Send(buf);
								}
            }
        }

        /* --- Tick del beep PWM (alternancia ON/OFF) --- */
        if ((flags & FLAG_CORR_BEEP_TICK) && s_active) {
            s_beep_on = !s_beep_on;
            if (s_beep_on) {
                AlarmaPWM_SetFrequency(CORRIENTE_FREQ_HZ);
                AlarmaPWM_On();
            } else {
                AlarmaPWM_Off();
            }
        }

        /* --- Tick del parpadeo de LEDs --- */
        if ((flags & FLAG_CORR_LED_TICK) && s_active) {
            s_led_on = !s_led_on;
            if (s_led_on) {
                LED_Encendido(0);
                LED_Encendido(1);
                LED_Encendido(2);
            } else {
                LED_Apagado(0);
                LED_Apagado(1);
                LED_Apagado(2);
            }
        }
    }
}