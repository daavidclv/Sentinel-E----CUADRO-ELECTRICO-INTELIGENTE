#ifndef __HISTORIAL_H
#define __HISTORIAL_H

#include "cmsis_os2.h"
#include <stdint.h>

/* =============================================================
 *  Modulo de historial de eventos persistente
 * =============================================================
 *  Almacena eventos en la Flash SPI externa W25Q128 / GD25Q128.
 *  Los eventos persisten tras reset o perdida de alimentacion.
 *
 *  FASE HIST-v3 (robustez): cada evento es un "slot" de
 *  TAMANO_MENSAJE bytes con la siguiente estructura plana:
 *
 *     byte[0]        : HIST_MAGIC (0x5A) -> marca de registro valido
 *     byte[1..N-1]   : texto "TIPO | FECHA HORA | DESCRIPCION\0"
 *
 *  Un slot libre (flash borrada) tiene byte[0] = 0xFF.
 *  Un slot a medias (corte de luz a mitad de escritura) NO lleva
 *  la marca 0x5A, asi que se detecta y NO trunca el resto del log.
 *
 *  Mapa de memoria:
 *    0x000000 - 0x000FFF  : Configuracion del sistema (NO TOCAR)
 *    0x001000 en adelante : Eventos del historial
 * ============================================================= */

#define TAMANO_MENSAJE       128U         /* antes 64; ampliado para fecha+hora */
#define HISTORIAL_INICIO     0x001000U    /* Sector 1, tras la configuracion   */
#define HIST_MAGIC           0x5AU        /* marca de slot valido               */

/* ---- API publica ---- */

/**
 * @brief Crea la cola de mensajes y lanza el hilo de historial.
 *        Al arrancar, localiza la siguiente posicion libre en Flash
 *        buscando el primer slot sin marca HIST_MAGIC valida.
 * @return 0 si OK, -1 si error.
 */
int Init_Thread_Historial(void);

/**
 * @brief Encola un evento para ser grabado en Flash.
 * @param tipo_evento "INFO", "ALARMA", "ACCESO", "PWR", "FIBRA", "CONFIG", ...
 * @param timestamp   "dd/mm/aaaa HH:MM:SS" (fecha + hora del RTC)
 * @param descripcion Descripcion breve del evento.
 */
void Guardar_En_Historial(const char* tipo_evento,
                          const char* timestamp,
                          const char* descripcion);

/**
 * @brief Lee un evento desde la Flash por su indice (0 = mas antiguo).
 * @param indice 0..N-1
 * @param salida Buffer de al menos TAMANO_MENSAJE bytes.
 * @note  Devuelve solo el TEXTO (sin la marca). Si el slot esta libre
 *        o corrupto, salida[0] valdra 0xFF (compatible con el CGI).
 */
void Leer_De_Historial(uint32_t indice, char* salida);

/**
 * @brief Devuelve el numero de eventos almacenados actualmente.
 * @return Numero de eventos validos (0 si la Flash esta vacia).
 */
uint32_t Historial_Num_Eventos(void);

/**
 * @brief Borra TODO el historial (varios sectores). Operacion lenta.
 *        Conserva la configuracion (sector 0). Reinicia el contador
 *        Y el puntero de escritura del hilo (corrige el race de v2).
 */
void Historial_Borrar_Todo(void);

#endif /* __HISTORIAL_H */