c s
.
