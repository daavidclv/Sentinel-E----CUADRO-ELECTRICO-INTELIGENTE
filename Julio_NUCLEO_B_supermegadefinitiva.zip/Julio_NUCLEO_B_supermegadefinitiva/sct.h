#ifndef sct_h
#define sct_h
#include "stm32f4xx_hal.h"
#include "cmsis_os2.h"
#include "ADC.h"

/* Mensaje de la cola de corriente */
typedef struct {
    float irms;       /* corriente RMS [A]                 */
    float potencia;   /* potencia aparente [VA] = 230*irms */
} messageCORR_t;

extern osThreadId_t       tid_ThCorriente;
extern osMessageQueueId_t id_MsgCorrQueue;
extern volatile float g_Irms_sct; 
int Init_ThCorriente(void);
#endif /* __CORRIENTE_H */