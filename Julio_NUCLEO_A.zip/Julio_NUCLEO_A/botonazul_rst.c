#include "stm32f4xx_hal.h"
#include "rtc.h"
#include "cmsis_os2.h"
#include "sntp.h"

GPIO_InitTypeDef GPIO_InitStruct;
extern osThreadId_t TID_LPWR;
extern osThreadId_t TID_Sntp;
//extern osThreadId_t id_tarea_rfid; /* A�adimos el hilo del RFID */

void BotonAzul_Init(void) { //PC13
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Habilitar el reloj del puerto C
    __HAL_RCC_GPIOC_CLK_ENABLE();

    // Configurar PC13 como entrada con interrupci�n por flanco de subida
    GPIO_InitStruct.Pin = GPIO_PIN_13;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    // Habilitar la interrupci�n en el controlador NVIC
    // Se usa la l�nea EXTI15_10 porque el pin es el 13
    HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0); 
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

// Manejador principal de la interrupci�n de hardware
void EXTI15_10_IRQHandler(void) {
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
}

// Callback  que se ejecuta tras procesar la interrupci�n
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    if (GPIO_Pin == GPIO_PIN_13) {
        
        // 1. Configuramos la hora a las 00:00:00
        //RTC_ConfTime(0, 0, 0);
       //osThreadFlagsSet(TID_Sntp, 0x01);
        // 2. Configuramos la fecha al 01-01-2000
        // Teniendo en cuenta la l�gica de tu funci�n RTC_ConfDate:
        // - El 1 de enero de 2000 fue S�bado (RTC_WEEKDAY_SATURDAY o 6)
        // - Pasamos 0 como mes porque internamente haces Month + 1
        // - Pasamos 100 como a�o porque internamente haces Year - 100
       // RTC_ConfDate(RTC_WEEKDAY_SATURDAY, 0, 1, 100);
			
			 // osThreadFlagsSet(TID_LPWR, 0x16);
//        if (id_tarea_rfid != NULL) {
//            osThreadFlagsSet(id_tarea_rfid, 0x01);
//        }
    }
	}
		
		