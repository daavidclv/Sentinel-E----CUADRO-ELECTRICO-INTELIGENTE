/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __THADC_H
#define __THADC_H
/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "cmsis_os2.h"
#include "adc.h"
/* Exported types ------------------------------------------------------------*/
/* Mensaje que publicar� el hilo del potenci�metro */
typedef struct {
    uint16_t voltage; /* tensi�n equivalente en mV */
	  uint16_t current; /* corriente equivalente en mA */
} messageADC_t;
/* Exported constants --------------------------------------------------------*/
/* Cola y thread del m�dulo POT */
extern osThreadId_t tid_ThADC;
extern osMessageQueueId_t id_MsgADCQueue;
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
  /* Exported thread functions */
  /* Inicializaci�n del m�dulo (ADC + hilo productor) */
  int Init_ThADC (void);
#endif /* __THADC_H */
/*********************************END OF FILE**********************************/
