#include "adc.h"
#include <math.h>

#define RESOLUTION_12B  4096U
#define VREF            3.3f
#define VBIAS           (VREF / 2.0f)   /* 1.65V DC midpoint from the bias circuit */
#define RMS_SAMPLES     200U            /* samples per RMS window (~20ms @ ~10kHz effective rate) */
#define RMS_WINDOW_MS   100U

/**
  * @brief Config the use of analog input ADC123_IN10 and enable ADC1 clock.
  *        Pin PC0 --> ADC1_IN10
  * @param None
  * @retval None
  */
void ADC1_pins_F429ZI_config(void) {
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	__HAL_RCC_ADC1_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	/* PC0  ------> ADC1_IN10 */
	GPIO_InitStruct.Pin  = GPIO_PIN_0;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}

/**
  * @brief Initialize the ADC for single conversions.
  *        12-bit resolution, software trigger, 1 conversion per start.
  * @param hadc         Pointer to an ADC_HandleTypeDef
  * @param ADC_Instance Hardware ADC peripheral (e.g. ADC1)
  * @retval  0  success
  * @retval -1  HAL_ADC_Init failed
  */
int ADC_Init_Single_Conversion(ADC_HandleTypeDef *hadc, ADC_TypeDef *ADC_Instance) {
	hadc->Instance                   = ADC_Instance;
	hadc->Init.ClockPrescaler        = ADC_CLOCK_SYNC_PCLK_DIV2;
	hadc->Init.Resolution            = ADC_RESOLUTION_12B;
	hadc->Init.ScanConvMode          = DISABLE;
	hadc->Init.ContinuousConvMode    = DISABLE;
	hadc->Init.DiscontinuousConvMode = DISABLE;
	hadc->Init.ExternalTrigConvEdge  = ADC_EXTERNALTRIGCONVEDGE_NONE;
	hadc->Init.ExternalTrigConv      = ADC_SOFTWARE_START;
	hadc->Init.DataAlign             = ADC_DATAALIGN_RIGHT;
	hadc->Init.NbrOfConversion       = 1;
	hadc->Init.DMAContinuousRequests = DISABLE;
	hadc->Init.EOCSelection          = ADC_EOC_SINGLE_CONV;
	if (HAL_ADC_Init(hadc) != HAL_OK) {
		return -1;
	}
	return 0;
}

/**
  * @brief Take a single ADC sample and return the corresponding voltage.
  *        Requires the OS tick to be running (HAL_ADC_PollForConversion uses HAL_GetTick).
  * @param hadc    Pointer to an initialised ADC_HandleTypeDef
  * @param Channel ADC channel number (e.g. ADC_CHANNEL_10)
  * @retval Voltage in volts [0 .. VREF], or -1 on channel config error
  */
float ADC_getVoltage(ADC_HandleTypeDef *hadc, uint32_t Channel) {
	ADC_ChannelConfTypeDef sConfig = {0};
	HAL_StatusTypeDef      status;
	uint32_t raw     = 0;
	float    voltage = 0.0f;

	sConfig.Channel      = Channel;
	sConfig.Rank         = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	if (HAL_ADC_ConfigChannel(hadc, &sConfig) != HAL_OK) {
		return -1.0f;
	}

	HAL_ADC_Start(hadc);
	do {
		status = HAL_ADC_PollForConversion(hadc, 0);
	} while (status != HAL_OK);

	raw     = HAL_ADC_GetValue(hadc);
	voltage = (float)raw * VREF / RESOLUTION_12B;

	return voltage;
}

/* ===================== FASE SCT-013 (anadido) ===================== */

/* Configura el canal UNA sola vez (rank + tiempo de muestreo).
   Asi en el bucle de muestreo NO reconfiguramos -> mucho mas rapido. */
void ADC_config_channel(ADC_HandleTypeDef *hadc, uint32_t Channel) {
    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = Channel;
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;   /* sube a _15/_28 si ves ruido */
    HAL_ADC_ConfigChannel(hadc, &sConfig);
}

/* Una conversion rapida (el canal ya debe estar configurado).
   Sondea el flag EOC directamente -> no usa HAL_GetTick, va fino. */
float ADC_read_voltage_fast(ADC_HandleTypeDef *hadc) {
    HAL_ADC_Start(hadc);
    while (__HAL_ADC_GET_FLAG(hadc, ADC_FLAG_EOC) == RESET);
    uint32_t raw = HAL_ADC_GetValue(hadc);   /* leer DR limpia el flag EOC */
    return (float)raw * VREF / RESOLUTION_12B;
}

/* ---------------------------------------------------------------------------
 * Usage example (RTOS thread)
 *
 * void Thread(void *argument) {
 *     ADC_HandleTypeDef adcHandle;
 *     ADC1_pins_F429ZI_config();
 *     ADC_Init_Single_Conversion(&adcHandle, ADC1);
 *
 *     while (1) {
 *         float rmsVoltage = ADC_getRMS(&adcHandle, ADC_CHANNEL_10);
 *         float rmsCurrent = rmsVoltage * 5.0f; // FACTOR: 5 A/V for SCT-013-005
 *         osDelay(250);
 *     }
 * }
 * ---------------------------------------------------------------------------*/