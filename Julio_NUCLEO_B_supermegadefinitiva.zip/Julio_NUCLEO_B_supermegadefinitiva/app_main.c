/*-----------------------------------------------------------------------------
 * app_main.c - NUCLEO-B (nodo remoto autonomo Sentinel E)
 *
 * ESTADO ACTUAL: FASE SCT (sobre FASE INA226/MODO2/PM/D/G)
 *   - FASE SCT: se anade medida de corriente AC de red (SCT-013-005)
 *     El hilo ThCorriente (sct.c) muestrea el ADC en PC0 y actualiza
 *     g_Irms_sct. El hilo TEMP lee esa variable y envia trama Q:<cA>\n
 *     por fibra al final de cada ciclo activo.
 *   - FASE INA226: la corriente de consumo y tension de bateria las
 *     proporciona el sensor INA226 por I2C3 (PH7/PH8).
 *   - LPWR_Mode coordina TEMP y RFID mediante flags
 *   - Boton azul (PC13) -> ciclo TEMP + RFID ; Timer RTC -> ciclo solo TEMP
 *   - Stop Mode real con wake-up por RTC/EXTI
 *   - 5 modos de ciclo (Rapido/Normal/Ahorro/Debug/Test)
 *
 * FLAGS DE COORDINACION (bits del osThreadFlags):
 *   0x10  -> LPWR despierta por timer RTC (solo TEMP)
 *   0x20  -> LPWR despierta por boton EXTI (TEMP + RFID)
 *   0x40  -> LPWR ordena a TEMP y RFID que empiecen (mismo bit, hilos distintos)
 *   0x80  -> TEMP avisa a LPWR de que termino
 *   0x100 -> RFID avisa a LPWR de que termino (bit separado para evitar colision)
 *---------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "rtc.h"
#include "LCD.h"
#include "LEDs.h"
#include "adc.h"
#include "stm32f4xx_hal.h"
#include "botonazul_rst.h"
#include "temp.h"                    // Driver LM75A (I2C propio)
#include "aplicacion_rfid.h"         // Driver MFRC522 (SPI5)
#include "cmsis_os2.h"
#include "lowpower_mode.h"           // Enter_Stop_Mode, Configurar_WakeUp_RTC
#include "fibra.h"                   // Fiber_Send, Fiber_Read, Fiber_Init
#include "alarma_motor.h"            // Logica de alarma por umbral de temperatura
#include "alarma_corriente.h"
#include "alarma_corriente_ac.h"     // FASE AC: alarma de banda para corriente AC red
#include "corriente.h"               // FASE INA226: sensor corriente/tension por I2C3
#include "sct.h"                     // FASE SCT: corriente AC red (SCT-013-005)

/* --- Stack del thread principal (multiplo de 8 bytes por AAPCS) --- */
#define APP_MAIN_STK_SZ (1024U)
uint64_t app_main_stk[APP_MAIN_STK_SZ / 8];
const osThreadAttr_t app_main_attr = {
  .stack_mem  = &app_main_stk[0],
  .stack_size = sizeof(app_main_stk)
};

/* Stack dedicado para el antiguo hilo TempFibra (ya no se usa, se conserva) */
static uint64_t tempfibra_stk[1024 / 8];
static const osThreadAttr_t tempfibra_attr = {
    .name = "TempFibra", .stack_mem = tempfibra_stk, .stack_size = sizeof(tempfibra_stk)
};

/* --- Variables globales --- */
ADC_HandleTypeDef adchandle;                            // Handle ADC1 (FASE PM, obsoleto)
char lcd_text[2][20+1] = { "NUCLEO-B ", "Esperando..." };

volatile float    g_ultima_temperatura  = 0.0f;   // Ultima temp leida por TEMP
volatile uint32_t g_lpwr_ciclos         = 0;      // Contador de ciclos run+stop
volatile uint32_t g_lpwr_estado         = 0;      // Estado actual (debug)
volatile float g_ultima_irms = 0.0f;

/* === FASE MODO: modo de ciclo activo ===
 * 0=Rapido, 1=Normal, 2=Ahorro, 3=Debug(sin Stop), 4=Test(Stop 5s) */
volatile uint8_t g_modo_ciclo = 1;   /* default: Normal */

/* FASE PM: ultimas medidas validas del subsistema analogico */
volatile uint16_t g_ultima_corriente_mA = 0;      // Corriente consumo (trama P:)
volatile uint16_t g_ultimo_voltaje_mV   = 0;      // Tension bateria   (trama P:)

/* --- Flags de coordinacion entre hilos --- */
#define FLAG_DESPIERTA_TIMER     0x10U    // Wake-up por RTC -> solo TEMP
#define FLAG_DESPIERTA_BOTON     0x20U    // Wake-up por EXTI -> TEMP + RFID
#define FLAG_TEMP_DESPIERTA      0x40U    // LPWR ordena inicio a TEMP
#define FLAG_TEMP_TERMINADO      0x80U    // TEMP avisa fin a LPWR
#define FLAG_RFID_DESPIERTA      0x40U    // LPWR ordena inicio a RFID (mismo bit, hilo distinto)
#define FLAG_RFID_TERMINADO      0x100U   // RFID avisa fin a LPWR (bit separado para WaitAll)

/* --- IDs de todos los hilos --- */
osThreadId_t TID_Display;     // LCD
osThreadId_t TID_Rtc;         // RTC
osThreadId_t TID_VIVO;        // Heartbeat LED
osThreadId_t TID_TEMP;        // Adquisicion temperatura + corriente
osThreadId_t TID_LPWR;        // Gestor del ciclo run/stop
osThreadId_t TID_TEST;        // (no usado)
osThreadId_t TID_FIBER_TX;    // (no usado, TX se hace desde TEMP/LPWR directamente)
osThreadId_t TID_FIBER_RX;    // (no usado aqui, ver TID_FibraRX)
osThreadId_t TID_TempFibra;   // (obsoleto, conservado)
osThreadId_t TID_FibraRX;     // Parser de comandos recibidos de NUCLEO-A

/* Colas de mensajes */
extern osMessageQueueId_t colatemp;     // Temperatura hacia consumidores internos
extern osMessageQueueId_t colaLCD_L1;  // Texto LCD linea 1
extern osMessageQueueId_t colaLCD_L2;  // Texto LCD linea 2
extern osThreadId_t id_tarea_rfid;     // ID del hilo RFID (creado por Aplicacion_RFID)

/* --- Prototipos internos --- */
static void Display        (void *arg);
static void CLKRTC         (void *arg);
static void VIVO           (void *arg);
static void TEMP           (void *arg);
static void LPWR_Mode      (void *arg);
static void Fiber_Rx_Thread(void *arg);

__NO_RETURN void app_main (void *arg);


/*============================================================================
  Display: gestor del LCD de NUCLEO-B.
============================================================================*/
static __NO_RETURN void Display(void *arg) {
  (void)arg;
  LCD_reset();
  Iniciacion_LCD();
  reset_buffer();
  while(1) {
    osThreadFlagsWait(0x02, osFlagsWaitAny, osWaitForever);
    reset_buffer();
    escribe(lcd_text[0], lcd_text[1]);
    LCD_update();
  }
}

/*============================================================================
  CLKRTC: inicializa el RTC de NUCLEO-B.
============================================================================*/
static void CLKRTC (void *arg) {
  (void)arg;
  RTC_Init();
  while(1) { osDelay(1000); }
}

/*============================================================================
  VIVO: heartbeat del LED1 (azul) a 5 Hz.
============================================================================*/
static void VIVO (void *arg) {
  (void)arg;
  while(1) {
    LED_Encendido(1); osDelay(100);
    LED_Apagado(1);   osDelay(100);
  }
}

/*============================================================================
  TEMP - FASE INA226 + FASE SCT:
  Ciclo de adquisicion de 5 lecturas en 5 segundos.
  En cada lectura:
    - Lee temperatura del LM75A (I2C propio)
    - Lee corriente (mA) y tension de bateria (mV) del INA226 (I2C3)
  Al final calcula media de corriente y envia por fibra:
    T:<ultima_temp>\n         -> temperatura LM75A
    P:<media_mA>,<vbat_mV>\n  -> consumo B + tension bateria
    Q:<iac_cA>\n              -> corriente AC red SCT-013-005 (FASE SCT)

  Nota INA226:
    - mA y mV salen YA escalados del sensor (sin conversion ADC manual).
    - El INA226 se inicializa UNA vez en app_main y sobrevive a Stop Mode
      (registros retenidos), por eso NO se re-inicializa en cada ciclo.
  Nota SCT:
    - g_Irms_sct la actualiza ThCorriente continuamente en background.
    - TEMP solo la lee al final del ciclo y la envia como trama Q:.
    - Se codifica en centiamperios (x100) para evitar float en el protocolo.
      Ejemplo: 3.47 A -> Q:347\n
============================================================================*/
static void TEMP (void *arg) {
  (void)arg;
  float    lectura = 0.0f;
  static char buf_fibra[40];
  int i;

  uint32_t suma_mA = 0;
  uint16_t v_mV    = 0;

  while(1) {
    /* 1. Esperar orden de LPWR */
    osThreadFlagsWait(FLAG_TEMP_DESPIERTA, osFlagsWaitAny, osWaitForever);

    /* 2. Re-inicializar perifericos tras Stop Mode */
    init_I2C();                          // LM75A (su bus I2C)
    /* FASE INA226: el INA226 (I2C3) NO se re-inicializa aqui; se configuro
     * una vez en app_main y sus registros sobreviven a Stop Mode. */
    /* FASE PM (obsoleto): init del ADC ----------------------------------
    ADC1_pins_F429ZI_config();
    ADC_Init_Single_Conversion(&hadc_pm, ADC1);
    -------------------------------------------------------------------- */

    /* 3. Reset acumuladores */
    suma_mA = 0;
    v_mV    = 0;

    /* LCD: inicio de ciclo activo */
    snprintf(lcd_text[0], 21, "T:--.-C  RUN");
    snprintf(lcd_text[1], 21, "Midiendo...");
    osThreadFlagsSet(TID_Display, 0x02);

    /* 4. 5 lecturas separadas 1 segundo */
    for (i = 0; i < 5; i++) {
      lectura = read_Temp();
      g_ultima_temperatura = lectura;
      printf("TEMP: %.1f C\r\n", lectura);

      Motor_Alarma_OnNewTemperature(lectura);
      osMessageQueuePut(colatemp, &lectura, 0, 0);

      {
        /* FASE INA226: corriente (mA) y tension de bus (mV) directas del
         * sensor por I2C. Sustituye a las 2 lecturas ADC. */
        uint16_t i_mA  = 0;
        uint16_t vb_mV = 0;

        if (INA226_Read(&i_mA, &vb_mV) == 0) {
            suma_mA += i_mA;
            v_mV     = vb_mV;        // se conserva la ultima lectura valida
        } else {
            printf("[B] INA226 lectura fallida\r\n");
        }

        printf("[B] INA226: I=%u mA, V=%u mV\r\n",
               (unsigned)i_mA, (unsigned)v_mV);

        /* FASE PM (obsoleto): lectura via ADC INA180A3 + MCP6001 ----------
        float    v_adc;
        uint16_t i_mA;
        v_adc = ADC_getVoltage(&hadc_pm, 10);
        i_mA  = (uint16_t)(v_adc * 1000.0f / (100.0f * 0.01f));
        suma_mA += i_mA;
        v_adc = ADC_getVoltage(&hadc_pm, 13);
        v_mV  = (uint16_t)(v_adc * 2000.0f);
        printf("[B] ADC: I=%u mA, V=%u mV\r\n", (unsigned)i_mA, (unsigned)v_mV);
        ----------------------------------------------------------------- */
      }

      /* Actualiza LCD con temperatura en cada lectura */
      snprintf(lcd_text[0], 21, "T:%.1fC  RUN", lectura);
      osThreadFlagsSet(TID_Display, 0x02);

      osDelay(1000);
    }

    /* 5. Calcula media y envia tramas por fibra */
    {
      uint16_t media_mA = (uint16_t)(suma_mA / 5U);
      g_ultima_corriente_mA = media_mA;
      g_ultimo_voltaje_mV   = v_mV;

      Motor_Corriente_OnNewMeasurement(media_mA);

      /* Trama T: temperatura LM75A */
      snprintf(buf_fibra, sizeof(buf_fibra), "T:%.1f\n", lectura);
      Fiber_Send(buf_fibra);
      printf("[B] TX fibra: %s", buf_fibra);

      /* Trama P: consumo B + tension bateria */
      snprintf(buf_fibra, sizeof(buf_fibra), "P:%u,%u\n",
               (unsigned)media_mA, (unsigned)v_mV);
      Fiber_Send(buf_fibra);
      printf("[B] TX fibra: %s", buf_fibra);
      printf("[B] Media corriente activo: %u mA (5 muestras)\r\n",
             (unsigned)media_mA);

/* === FASE SCT: trama Q: corriente AC red en centiamperios (x100) ===
 * Se consume DIRECTAMENTE de la cola id_MsgCorrQueue, igual que hacia
 * ThTestPot en el proyecto aislado, para garantizar el MISMO valor.
 * Se usa timeout corto (no osWaitForever) porque TEMP() no puede
 * bloquearse esperando al SCT sin romper el ciclo LPWR.              */
{
    static float  ultimo_irms = 0.0f;   /* persiste entre ciclos de TEMP() */
    messageCORR_t msg_sct;
    uint16_t      iac_cA;

    /* Vacia la cola y se queda con el mensaje mas reciente, si lo hay */
    while (osMessageQueueGet(id_MsgCorrQueue, &msg_sct, NULL, 0U) == osOK) {
        ultimo_irms = msg_sct.irms;
    }
		
		g_ultima_irms = ultimo_irms;
    iac_cA = (uint16_t)(ultimo_irms * 100.0f);

    /* FASE AC: alimenta el motor de alarma de banda con el MISMO valor
     * que se envia a A por fibra, para que ambos lados vean el mismo dato. */
    Motor_CorrienteAC_OnNewMeasurement(iac_cA);

    snprintf(buf_fibra, sizeof(buf_fibra), "Q:%u\n", (unsigned)iac_cA);
    Fiber_Send(buf_fibra);
    printf("[B] TX fibra SCT: %s", buf_fibra);
}

      /* LCD: resumen final del ciclo activo */
      snprintf(lcd_text[0], 21, "T:%.1fC  RUN", lectura);
      snprintf(lcd_text[1], 21, "I:%umA V:%.1fV",
               (unsigned)media_mA,
               v_mV / 1000.0f);
      osThreadFlagsSet(TID_Display, 0x02);
    }

    /* 6. Avisar a LPWR de que hemos terminado */
    osThreadFlagsSet(TID_LPWR, FLAG_TEMP_TERMINADO);
  }
}

/*============================================================================
  LPWR_Mode - FASE D/PM/MODO2: gestor del ciclo de vida de NUCLEO-B.
============================================================================*/
static void LPWR_Mode (void *arg) {
  (void)arg;
  uint32_t motivo_despertar;
  uint32_t flags_a_esperar;

  /* Primer ciclo: tratar como si hubiera pulsado el boton (ciclo completo) */
  motivo_despertar = FLAG_DESPIERTA_BOTON;

  while(1) {

    /* === RUN MODE === */
    LED_Encendido(0);
    g_lpwr_ciclos++;
    g_lpwr_estado = 2;

    if (motivo_despertar == FLAG_DESPIERTA_TIMER) {
      printf("LPWR: ciclo por TIMER -> solo TEMP\r\n");
      osThreadFlagsSet(TID_TEMP, FLAG_TEMP_DESPIERTA);
      flags_a_esperar = FLAG_TEMP_TERMINADO;
    } else {
      printf("LPWR: ciclo por BOTON -> TEMP + RFID\r\n");
      osThreadFlagsSet(TID_TEMP,      FLAG_TEMP_DESPIERTA);
      osThreadFlagsSet(id_tarea_rfid, FLAG_RFID_DESPIERTA);
      flags_a_esperar = FLAG_TEMP_TERMINADO | FLAG_RFID_TERMINADO;
    }

    osThreadFlagsWait(flags_a_esperar, osFlagsWaitAll, osWaitForever);

    osThreadFlagsClear(FLAG_DESPIERTA_BOTON | FLAG_DESPIERTA_TIMER);
    osThreadFlagsClear(FLAG_DESPIERTA_BOTON | FLAG_DESPIERTA_TIMER); // doble clear intencionado

    printf("LPWR: ciclo completado\r\n");

    while (Motor_Alarma_IsActive()) {
        printf("LPWR: alarma activa, inhibiendo Stop\r\n");
        osThreadFlagsSet(TID_TEMP, FLAG_TEMP_DESPIERTA);
        osThreadFlagsWait(FLAG_TEMP_TERMINADO, osFlagsWaitAny, osWaitForever);
    }

    /* === FASE MODO2: modo DEBUG -> sin Stop, ciclo continuo === */
    if (g_modo_ciclo == 3U) {
        printf("LPWR: modo DEBUG (sin Stop), reanudando en 1s\r\n");
        snprintf(lcd_text[0], 21, "T:%.1fC DEBUG", g_ultima_temperatura);
        snprintf(lcd_text[1], 21, "Ciclo #%lu", (unsigned long)g_lpwr_ciclos);
        osThreadFlagsSet(TID_Display, 0x02);

        osDelay(1000);

        {
            uint32_t f = osThreadFlagsWait(
                            FLAG_DESPIERTA_BOTON | FLAG_DESPIERTA_TIMER,
                            osFlagsWaitAny, 0U);
            if (f < 0x80000000U && (f & FLAG_DESPIERTA_BOTON))
                motivo_despertar = FLAG_DESPIERTA_BOTON;
            else
                motivo_despertar = FLAG_DESPIERTA_TIMER;
        }

        Fiber_Send("?H\n");
        Fiber_Send("?C\n");
        Fiber_Send("?M\n");
        Fiber_Send("?D\n");
        osDelay(150);
        continue;
    }

    /* === STOP MODE === */
    LED_Apagado(0);

    {
        uint32_t segundos_stop;
        switch (g_modo_ciclo) {
            case 0:  segundos_stop = 25U;  break;   /* Rapido */
            case 2:  segundos_stop = 115U; break;   /* Ahorro */
            case 4:  segundos_stop = 5U;   break;   /* Test   */
            default: segundos_stop = 55U;  break;   /* Normal */
        }
        printf("LPWR: Stop %lu s (modo %u)\r\n",
               (unsigned long)segundos_stop, (unsigned)g_modo_ciclo);
        Configurar_WakeUp_RTC(segundos_stop);
    }

    snprintf(lcd_text[0], 21, "T:%.1fC  STOP", g_ultima_temperatura);
    snprintf(lcd_text[1], 21, "Ciclo #%lu", (unsigned long)g_lpwr_ciclos);
    osThreadFlagsSet(TID_Display, 0x02);
    osDelay(50);

    Enter_Stop_Mode();

    motivo_despertar = osThreadFlagsWait(FLAG_DESPIERTA_BOTON | FLAG_DESPIERTA_TIMER,
                                          osFlagsWaitAny, 100U);

    if (motivo_despertar >= 0x80000000U) {
        printf("LPWR: WARNING wake-up sin flag identificada\r\n");
        motivo_despertar = FLAG_DESPIERTA_TIMER;
    } else if (motivo_despertar & FLAG_DESPIERTA_BOTON) {
        motivo_despertar = FLAG_DESPIERTA_BOTON;
    } else {
        motivo_despertar = FLAG_DESPIERTA_TIMER;
    }

    osDelay(50);

    Fiber_Send("?H\n");
    Fiber_Send("?C\n");
    Fiber_Send("?M\n");
    Fiber_Send("?D\n");
    osDelay(150);
  }
}

/*============================================================================
  Fiber_Rx_Thread - FASE G: parser de comandos de NUCLEO-A por fibra.
============================================================================*/
static void Fiber_Rx_Thread(void *arg) {
    (void)arg;
    static char linea[64];
    static int pos = 0;

    while (1) {
        uint8_t b = Fiber_Read();

        if (b == 0) { osDelay(10); continue; }

        if (b == '\n' || b == '\r') {
            if (pos > 0) {
                linea[pos] = '\0';
                printf("[B] RX linea: %s\r\n", linea);

                if (linea[0] == 'H' && linea[1] == ':') {
                    int temp = atoi(&linea[2]);
                    if (temp > 0 && temp < 150) {
                        Motor_Alarma_SetThreshold((float)temp);
                    } else {
                        printf("[B] Umbral fuera de rango: %d\r\n", temp);
                    }
                }
                else if (linea[0] == 'C' && linea[1] == ':') {
                    int corriente = atoi(&linea[2]);
                    if (corriente > 0 && corriente < 5000) {
                        Motor_Corriente_SetThreshold((uint16_t)corriente);
                    } else {
                        printf("[B] Umbral corriente fuera de rango: %d\r\n", corriente);
                    }
                }
                else if (linea[0] == 'M' && linea[1] == ':') {
                    int modo = atoi(&linea[2]);
                    if (modo >= 0 && modo <= 4) {
                        g_modo_ciclo = (uint8_t)modo;
                        printf("[B] Modo ciclo: %u\r\n", (unsigned)g_modo_ciclo);
                    } else {
                        printf("[B] Modo fuera de rango: %d\r\n", modo);
                    }
                }
                /* === FASE AC: D:<bajo_cA>,<alto_cA> -> banda de corriente AC ===
                 * Ejemplo: D:60,170\n  ->  banda normal 0.60..1.70 A */
                else if (linea[0] == 'D' && linea[1] == ':') {
                    char *coma = strchr(&linea[2], ',');
                    if (coma != NULL) {
                        *coma = '\0';
                        int bajo = atoi(&linea[2]);
                        int alto = atoi(coma + 1);
                        if (bajo >= 0 && alto > bajo && alto < 100000) {
                            Motor_CorrienteAC_SetUmbrales((uint16_t)bajo, (uint16_t)alto);
                        } else {
                            printf("[B] Banda AC fuera de rango: %d..%d\r\n", bajo, alto);
                        }
                    } else {
                        printf("[B] Trama D: mal formada (falta coma): %s\r\n", linea);
                    }
                }

                pos = 0;
            }
        } else {
            if (pos < (int)sizeof(linea) - 1) {
                linea[pos++] = (char)b;
            } else {
                printf("[B] RX overflow, descartando linea\r\n");
                pos = 0;
            }
        }
    }
}

/*============================================================================
  app_main: inicializa NUCLEO-B y lanza todos los hilos.
============================================================================*/
__NO_RETURN void app_main (void *arg) {
  (void)arg;

  /* Colas de mensajes */
  colaLCD_L1 = osMessageQueueNew(5, 20*sizeof(char), NULL);
  colaLCD_L2 = osMessageQueueNew(5, 20*sizeof(char), NULL);
  colatemp   = osMessageQueueNew(10, sizeof(float), NULL);

  /* Perifericos */
  BotonAzul_Init();
  LED_Init();
  Aplicacion_RFID_Inicializar();
  Fiber_Init();

  /* === FASE SCT: arranca el hilo de medida de corriente AC en background ===
   * ThCorriente muestrea PC0/ADC1_IN10 continuamente y actualiza g_Irms_sct.
   * TEMP lo lee al final de cada ciclo activo y lo envia como trama Q:.    */
  if (Init_ThCorriente() != 0) {
      printf("[WARN] Init_ThCorriente fallo: sin medida SCT\r\n");
  }

  /* Motor de alarma de temperatura */
  if (Motor_Alarma_Init() != 0) {
      printf("[FATAL] Motor_Alarma_Init fallo\r\n");
      while (1) {}
  }

  /* Motor de alarma de corriente */
  if (Motor_Corriente_Init() != 0) {
      printf("[FATAL] Motor_Corriente_Init fallo\r\n");
      while (1) {}
  }

  /* FASE AC: motor de alarma de banda para corriente AC de red (SCT-013).
   * NO es FATAL: si falla, el nodo sigue operativo, solo se pierde la
   * vigilancia de banda de corriente AC. */
  if (Motor_CorrienteAC_Init() != 0) {
      printf("[WARN] Motor_CorrienteAC_Init fallo: sin alarma de banda AC\r\n");
  }

  /* FASE INA226: sensor de corriente/tension por I2C3 (PH7/PH8).
   * No es FATAL: si falla, el nodo sigue operativo sin medida de consumo. */
  if (INA226_Init() != 0) {
      printf("[WARN] INA226_Init fallo: sin medida de consumo\r\n");
  }

  /* Pide umbrales iniciales a NUCLEO-A antes de lanzar los hilos */
  osDelay(3000);
  Fiber_Send("?H\n");
  Fiber_Send("?C\n");
  Fiber_Send("?M\n");
  Fiber_Send("?D\n");

  /* Lanzamiento de hilos */
  TID_Display = osThreadNew(Display,         NULL, NULL);
  TID_Rtc     = osThreadNew(CLKRTC,          NULL, NULL);
  TID_VIVO    = osThreadNew(VIVO,            NULL, NULL);
  TID_TEMP    = osThreadNew(TEMP,            NULL, NULL);
  TID_LPWR    = osThreadNew(LPWR_Mode,       NULL, NULL);
  TID_FibraRX = osThreadNew(Fiber_Rx_Thread, NULL, NULL);

  Aplicacion_RFID_Crear_Tarea();

  osThreadExit();
}

/* Redireccion de printf hacia ITM/SWO */
struct __FILE { int handle; };
FILE __stdout;
FILE __stdin;
int fputc(int ch, FILE *f) { return (ITM_SendChar(ch)); }