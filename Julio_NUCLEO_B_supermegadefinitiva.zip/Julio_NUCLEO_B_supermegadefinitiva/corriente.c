/*-----------------------------------------------------------------------------
 * ina226.c - FASE INA226
 * Driver INA226 sobre CMSIS-Driver I2C3 (callback + semaforo).
 *
 * CONEXIONADO:
 *   [4xAA ~6V] -> VIN+ --[shunt]-- VIN- -> [entrada MT3608] -> E5V Nucleo-B
 *   VBUS  -> VIN+ (para medir la tension del pack de pilas)
 *   VCC   -> 3.3V        GND -> GND comun
 *   SCL   -> PH7         SDA -> PH8       A0=GND A1=GND -> dir 0x40
 *---------------------------------------------------------------------------*/

#include "corriente.h"
#include "Driver_I2C.h"
#include "cmsis_os2.h"
#include <stdio.h>

extern ARM_DRIVER_I2C Driver_I2C2;
#define INA226_I2C        (&Driver_I2C2)

#define INA226_I2C_ADDR    0x40U   /* 7-bit, A0=GND A1=GND */

/* --- Registros INA226 --- */
#define INA226_REG_CONFIG    0x00U
#define INA226_REG_SHUNT_V   0x01U
#define INA226_REG_BUS_V     0x02U
#define INA226_REG_POWER     0x03U
#define INA226_REG_CURRENT   0x04U
#define INA226_REG_CALIB     0x05U
#define INA226_REG_MANUF_ID  0xFEU   /* debe valer 0x5449 ("TI") */

/* --- Calibracion ---
 * R_shunt = 0.1 Ohm (modulo CJMCU-226 con shunt R100).
 *   !!! VERIFICA el shunt real de tu modulo. Si trae 2 mOhm (modulos "20A"),
 *       cambia INA226_R_SHUNT a 0.002f. Para medir mA se RECOMIENDA 0.1 Ohm.
 *       Con 0.1 Ohm el rango maximo es 81.92mV/0.1 = ~819 mA, ideal aqui.
 * Current_LSB = 0.1 mA/bit.
 * CAL = 0.00512 / (Current_LSB[A] * R_shunt[Ohm])
 *     = 0.00512 / (0.0001 * 0.1) = 512 = 0x0200 */
#define INA226_R_SHUNT         0.01f
#define INA226_CURRENT_LSB_mA  1.0f
#define INA226_CALIB_VALUE     512U

/* Config: bit14=1(reset), AVG=16, VBUSCT=1.1ms, VSHCT=1.1ms, continuo shunt+bus
 *   0100 011 100 100 111 = 0x4727 */
#define INA226_CONFIG_VALUE    0x4727U

/* VBUS LSB = 1.25 mV */

static osSemaphoreId_t   ina226_sem        = NULL;
static volatile uint32_t ina226_last_event = 0U;

/* Callback del driver I2C3: libera el semaforo al terminar la transferencia */
static void INA226_I2C_Callback(uint32_t event) {
  ina226_last_event = event;
  if (event & (ARM_I2C_EVENT_TRANSFER_DONE       |
               ARM_I2C_EVENT_TRANSFER_INCOMPLETE |
               ARM_I2C_EVENT_ADDRESS_NACK        |
               ARM_I2C_EVENT_BUS_ERROR           |
               ARM_I2C_EVENT_ARBITRATION_LOST)) {
    if (ina226_sem != NULL) {
      osSemaphoreRelease(ina226_sem);
    }
  }
}

/* Espera fin de transferencia con timeout. 0 OK, -1 timeout/error de bus */
static int INA226_Wait(void) {
  if (osSemaphoreAcquire(ina226_sem, 100U) != osOK) {
    printf("[INA226] timeout I2C\r\n");
    return -1;
  }
  if (ina226_last_event & (ARM_I2C_EVENT_ADDRESS_NACK        |
                           ARM_I2C_EVENT_BUS_ERROR           |
                           ARM_I2C_EVENT_ARBITRATION_LOST    |
                           ARM_I2C_EVENT_TRANSFER_INCOMPLETE)) {
    printf("[INA226] error I2C evt=0x%lX\r\n", (unsigned long)ina226_last_event);
    return -1;
  }
  return 0;
}

/* Escribe un registro de 16 bits (MSB primero) */
static int INA226_WriteReg(uint8_t reg, uint16_t val) {
  uint8_t tx[3];
  tx[0] = reg;
  tx[1] = (uint8_t)(val >> 8);
  tx[2] = (uint8_t)(val & 0xFFU);
  if (INA226_I2C->MasterTransmit(INA226_I2C_ADDR, tx, 3U, false) != ARM_DRIVER_OK)
    return -1;
  return INA226_Wait();
}

/* Lee un registro de 16 bits: write puntero (repeated start) + read 2 bytes */
static int INA226_ReadReg(uint8_t reg, uint16_t *val) {
  uint8_t rx[2];
  if (INA226_I2C->MasterTransmit(INA226_I2C_ADDR, &reg, 1U, true) != ARM_DRIVER_OK)
    return -1;
  if (INA226_Wait() != 0) return -1;
  if (INA226_I2C->MasterReceive(INA226_I2C_ADDR, rx, 2U, false) != ARM_DRIVER_OK)
    return -1;
  if (INA226_Wait() != 0) return -1;
  *val = ((uint16_t)rx[0] << 8) | (uint16_t)rx[1];
  return 0;
}

int INA226_Init(void) {
  uint16_t id = 0;

  if (ina226_sem == NULL) {
    ina226_sem = osSemaphoreNew(1U, 0U, NULL);
    if (ina226_sem == NULL) return -1;
  }

  if (INA226_I2C->Initialize(INA226_I2C_Callback) != ARM_DRIVER_OK) return -1;
  if (INA226_I2C->PowerControl(ARM_POWER_FULL)    != ARM_DRIVER_OK) return -1;
  if (INA226_I2C->Control(ARM_I2C_BUS_SPEED,
                          ARM_I2C_BUS_SPEED_FAST) != ARM_DRIVER_OK) return -1;

  /* Comprueba que el chip responde */
  if (INA226_ReadReg(INA226_REG_MANUF_ID, &id) != 0) {
    printf("[INA226] no responde en Init\r\n");
    return -1;
  }
  if (id != 0x5449U) {
    printf("[INA226] WARNING Manuf ID=0x%04X (esperado 0x5449)\r\n", (unsigned)id);
    /* No abortamos: algunos clones devuelven otro ID */
  }

  if (INA226_WriteReg(INA226_REG_CONFIG, INA226_CONFIG_VALUE) != 0) return -1;
  if (INA226_WriteReg(INA226_REG_CALIB,  INA226_CALIB_VALUE)  != 0) return -1;

  printf("[INA226] init OK (ID=0x%04X)\r\n", (unsigned)id);
  return 0;
}

int INA226_Read_Current_mA(uint16_t *out_mA) {
  uint16_t raw;
  int16_t  s;
  if (out_mA == NULL) return -1;
  if (INA226_ReadReg(INA226_REG_CURRENT, &raw) != 0) return -1;
  s = (int16_t)raw;            /* registro con signo (bidireccional) */
  if (s < 0) s = 0;            /* en este montaje el consumo es positivo */
  *out_mA = (uint16_t)((float)s * INA226_CURRENT_LSB_mA + 0.5f);
  return 0;
}

int INA226_Read_BusVoltage_mV(uint16_t *out_mV) {
  uint16_t raw;
  if (out_mV == NULL) return -1;
  if (INA226_ReadReg(INA226_REG_BUS_V, &raw) != 0) return -1;
  /* LSB = 1.25 mV -> mV = raw * 5 / 4 (entero, sin float) */
  *out_mV = (uint16_t)(((uint32_t)raw * 5U) / 4U);
  return 0;
}

int INA226_Read(uint16_t *out_mA, uint16_t *out_mV) {
  if (INA226_Read_Current_mA(out_mA)   != 0) return -1;
  if (INA226_Read_BusVoltage_mV(out_mV) != 0) return -1;
  return 0;
}