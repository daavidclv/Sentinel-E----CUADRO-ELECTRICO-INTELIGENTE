#ifndef __THTESTCORRIENTE_H
#define __THTESTCORRIENTE_H

#include "cmsis_os2.h"
#include "sct.h"

extern osThreadId_t tid_ThTestPot;
extern float        g_PotIrms;       /* ultima corriente RMS leida [A] */
extern float        g_PotPotencia;   /* ultima potencia leida [VA]     */
extern uint32_t      g_PotCount;

int Init_ThTestPot (void);

#endif /* __THTESTPOT_H */