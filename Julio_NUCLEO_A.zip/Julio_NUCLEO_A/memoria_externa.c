/*------------------------------------------------------------------------------
 *  Driver Flash SPI externa para W25Q128FV / GD25Q128
 *  Proyecto Sentinel E - ISE 2025/2026
 *
 *  FASE HIST-v3: se anade un MUTEX que serializa TODA operacion sobre el
 *  bus SPI (lectura, escritura, borrado, ID). Esto impide que una lectura
 *  del historial desde el hilo del servidor HTTP se solape con una
 *  escritura/borrado del Thread_Historial (o con el guardado de config),
 *  que era la causa intermitente de corrupcion de la flash.
 *
 *  Funciones expuestas:
 *    - Memoria_Init        : inicializa SPI3, GPIO del CS y el mutex
 *    - Memoria_ReadID      : lee el JEDEC ID para verificar conectividad
 *    - Memoria_ReadData    : lectura continua de datos
 *    - Memoria_WritePage   : escritura de hasta 256 bytes en una pagina
 *    - Memoria_EraseSector : borrado de un sector de 4 KiB
 *
 *  Funciones internas (static):
 *    - WriteEnable, WaitBusy, GPIO_Init (se llaman YA dentro del mutex)
 *----------------------------------------------------------------------------*/

#include "memoria_externa.h"
#include "cmsis_os2.h"            /* FASE HIST-v3: mutex del bus */

/* Driver SPI3 configurado en el RTE de Keil */
extern ARM_DRIVER_SPI Driver_SPI3;
static ARM_DRIVER_SPI* const SPI_Mem_drv = &Driver_SPI3;

/* FASE HIST-v3: mutex que protege el acceso al bus SPI de la flash */
static osMutexId_t mem_mutex = NULL;

/* Macros de toma/cesion del mutex (seguras si aun no esta creado) */
#define MEM_LOCK()    do { if (mem_mutex) osMutexAcquire(mem_mutex, osWaitForever); } while (0)
#define MEM_UNLOCK()  do { if (mem_mutex) osMutexRelease(mem_mutex);               } while (0)

/* Macros de control del Chip Select (PD2) */
#define CS_LOW()   HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET)
#define CS_HIGH()  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET)

/* Espera activa hasta que el driver CMSIS SPI deje de estar ocupado */
static inline void SPI_WaitReady(void) {
    while (SPI_Mem_drv->GetStatus().busy) { /* spin */ }
}

/* ------------------------------------------------------------------
 *  Inicializacion del GPIO para el Chip Select (PD2)
 * ------------------------------------------------------------------ */
static void GPIO_Mem_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOD_CLK_ENABLE();

    GPIO_InitStruct.Pin   = GPIO_PIN_2;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    CS_HIGH();   /* memoria deseleccionada al arrancar */
}

/* ------------------------------------------------------------------
 *  Memoria_Init
 *  Inicializa el driver CMSIS SPI3 en modo maestro, SPI Mode 0, 8 bits,
 *  el GPIO del CS y el mutex del bus. Velocidad 1 MHz.
 * ------------------------------------------------------------------ */
void Memoria_Init(void) {
    GPIO_Mem_Init();

    /* FASE HIST-v3: crear el mutex antes de cualquier acceso */
    if (mem_mutex == NULL) {
        mem_mutex = osMutexNew(NULL);
    }

    SPI_Mem_drv->Initialize(NULL);
    SPI_Mem_drv->PowerControl(ARM_POWER_FULL);
    SPI_Mem_drv->Control(ARM_SPI_MODE_MASTER |
                         ARM_SPI_CPOL0_CPHA0 |
                         ARM_SPI_MSB_LSB     |
                         ARM_SPI_DATA_BITS(8),
                         1000000U);
}

/* ------------------------------------------------------------------
 *  Memoria_ReadID
 * ------------------------------------------------------------------ */
uint32_t Memoria_ReadID(void) {
    uint8_t cmd = W25Q_CMD_JEDEC_ID;
    uint8_t id[3] = {0};

    MEM_LOCK();
    CS_LOW();
    SPI_Mem_drv->Send(&cmd, 1);
    SPI_WaitReady();
    SPI_Mem_drv->Receive(id, 3);
    SPI_WaitReady();
    CS_HIGH();
    MEM_UNLOCK();

    return ((uint32_t)id[0] << 16) | ((uint32_t)id[1] << 8) | id[2];
}

/* ------------------------------------------------------------------
 *  Memoria_ReadData
 * ------------------------------------------------------------------ */
void Memoria_ReadData(uint32_t address, uint8_t *pData, uint32_t size) {
    uint8_t cmd[4];

    cmd[0] = W25Q_CMD_READ_DATA;
    cmd[1] = (address >> 16) & 0xFF;
    cmd[2] = (address >> 8)  & 0xFF;
    cmd[3] =  address        & 0xFF;

    MEM_LOCK();
    CS_LOW();
    SPI_Mem_drv->Send(cmd, 4);
    SPI_WaitReady();
    SPI_Mem_drv->Receive(pData, size);
    SPI_WaitReady();
    CS_HIGH();
    MEM_UNLOCK();
}

/* ------------------------------------------------------------------
 *  Memoria_WaitBusy (interna) - se llama YA dentro del mutex
 * ------------------------------------------------------------------ */
static void Memoria_WaitBusy(void) {
    uint8_t cmd = W25Q_CMD_READ_STATUS_1;
    uint8_t status_reg = 0xFF;

    CS_LOW();
    SPI_Mem_drv->Send(&cmd, 1);
    SPI_WaitReady();

    do {
        SPI_Mem_drv->Receive(&status_reg, 1);
        SPI_WaitReady();
    } while ((status_reg & 0x01) == 0x01);

    CS_HIGH();
}

/* ------------------------------------------------------------------
 *  Memoria_WriteEnable (interna) - se llama YA dentro del mutex
 * ------------------------------------------------------------------ */
static void Memoria_WriteEnable(void) {
    uint8_t cmd = W25Q_CMD_WRITE_ENABLE;
    CS_LOW();
    SPI_Mem_drv->Send(&cmd, 1);
    SPI_WaitReady();
    CS_HIGH();
}

/* ------------------------------------------------------------------
 *  Memoria_EraseSector
 *  Borra un sector de 4 KiB. La direccion se alinea a 4 KiB.
 *  TODO el ciclo (WriteEnable + Erase + WaitBusy) bajo un solo mutex.
 * ------------------------------------------------------------------ */
void Memoria_EraseSector(uint32_t address) {
    uint8_t cmd[4];

    address &= ~(W25Q_SECTOR_SIZE - 1U);   /* alinear a 4 KiB */

    MEM_LOCK();

    Memoria_WriteEnable();

    cmd[0] = W25Q_CMD_SECTOR_ERASE;
    cmd[1] = (address >> 16) & 0xFF;
    cmd[2] = (address >> 8)  & 0xFF;
    cmd[3] =  address        & 0xFF;

    CS_LOW();
    SPI_Mem_drv->Send(cmd, 4);
    SPI_WaitReady();
    CS_HIGH();

    Memoria_WaitBusy();

    MEM_UNLOCK();
}

/* ------------------------------------------------------------------
 *  Memoria_WritePage
 *  Escribe hasta 256 bytes en una pagina. El sector debe estar borrado.
 *  TODO el ciclo (WriteEnable + Program + WaitBusy) bajo un solo mutex.
 * ------------------------------------------------------------------ */
void Memoria_WritePage(uint32_t address, uint8_t *pData, uint32_t size) {
    uint8_t cmd[4];

    if (size == 0U || size > W25Q_PAGE_SIZE) return;

    MEM_LOCK();

    Memoria_WriteEnable();

    cmd[0] = W25Q_CMD_PAGE_PROGRAM;
    cmd[1] = (address >> 16) & 0xFF;
    cmd[2] = (address >> 8)  & 0xFF;
    cmd[3] =  address        & 0xFF;

    CS_LOW();
    SPI_Mem_drv->Send(cmd, 4);
    SPI_WaitReady();
    SPI_Mem_drv->Send(pData, size);
    SPI_WaitReady();
    CS_HIGH();

    Memoria_WaitBusy();

    MEM_UNLOCK();
}