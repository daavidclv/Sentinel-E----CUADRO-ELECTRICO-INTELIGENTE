/* ============================================================================
 * FASE G � alarma_corriente.h
 * Motor de alarma de corriente con hist�resis y patr�n beep r�pido.
 * An�logo a alarma_motor.h pero para corriente en mA.
 * ========================================================================== */
#ifndef ALARMA_CORRIENTE_H
#define ALARMA_CORRIENTE_H

#include <stdint.h>
#include <stdbool.h>
#include "cmsis_os2.h"

/* Umbral por defecto en mA (sobrescribible por A v�a C:<valor>). */
#define ALARMA_CORRIENTE_THRESHOLD_DEFAULT_MA   400U

/* Hist�resis: desactiva cuando baja de (umbral - HYST) mA. */
#define ALARMA_CORRIENTE_HYSTERESIS_MA          20U

/* Inicializa el motor de alarma de corriente. Llamar una vez al arranque.
 * NO inicializa el PWM (lo comparte con alarma_motor). */
int Motor_Corriente_Init(void);

/* Llamado por TEMP en cada ciclo con la media de corriente medida. */
void Motor_Corriente_OnNewMeasurement(uint16_t corriente_mA);

/* Llamado por el parser de fibra cuando llega C:<valor> desde A. */
void Motor_Corriente_SetThreshold(uint16_t umbral_mA);

/* Consulta de estado (para inhibir Stop Mode si aplica). */
bool Motor_Corriente_IsActive(void);

/* Devuelve el umbral actual en mA. */
uint16_t Motor_Corriente_GetThreshold(void);

#endif /* ALARMA_CORRIENTE_H */