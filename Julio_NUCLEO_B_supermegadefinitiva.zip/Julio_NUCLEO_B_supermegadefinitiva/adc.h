#ifndef __ADC_H
#define __ADC_H                       /* <-- FALTABA: cierra bien la guarda */
#include "stm32f4xx_hal.h"

void  ADC1_pins_F429ZI_config(void);
int   ADC_Init_Single_Conversion(ADC_HandleTypeDef *, ADC_TypeDef *);
float ADC_getVoltage(ADC_HandleTypeDef *, uint32_t);

/* ---- FASE SCT-013: lectura rapida para senales AC ---- */
void  ADC_config_channel(ADC_HandleTypeDef *, uint32_t);
float ADC_read_voltage_fast(ADC_HandleTypeDef *);
#endif /* __ADC_H */