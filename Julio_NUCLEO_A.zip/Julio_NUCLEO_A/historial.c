/*------------------------------------------------------------------------------
 *  Modulo de historial de eventos persistente
 *  Proyecto Sentinel E - ISE 2025/2026
 *
 *  FASE HIST-v3 (robustez "100% consistente"):
 *    - Cada slot empieza por HIST_MAGIC (0x5A): registro auto-descriptivo.
 *      Una pagina a medias por corte de luz NO trunca el resto del log.
 *    - El puntero de escritura es GLOBAL (g_dir_escritura), no local al hilo,
 *      para que Historial_Borrar_Todo() pueda reiniciarlo sin race.
 *    - El bus SPI esta serializado por mutex dentro de memoria_externa.c,
 *      asi una lectura web no puede corromper una escritura simultanea.
 *
 *  Sobre la v2 anterior (bug que borraba el historial al quitar alimentacion):
 *    el "primer 0xFF" como fin de log era fragil; un solo byte mal leido
 *    ponia g_num_eventos a 0 y ocultaba todo. Ahora se usa la marca 0x5A.
 *----------------------------------------------------------------------------*/

#include "historial.h"
#include "memoria_externa.h"
#include <stdio.h>
#include <string.h>

/* Identificadores RTOS */
static osThreadId_t       tid_Thread_Historial;
static osMessageQueueId_t colaHistorial;

/* Numero de eventos validos en la Flash. Accesible desde el CGI. */
static uint32_t g_num_eventos = 0;

/* FASE HIST-v3: puntero de escritura GLOBAL (antes era local al hilo).
   Permite que Historial_Borrar_Todo() lo reinicie de forma efectiva. */
static volatile uint32_t g_dir_escritura = HISTORIAL_INICIO;

/* Prototipos locales */
static void     Thread_Historial(void *argument);
static int      Slot_Es_Valido(uint32_t direccion);
static uint32_t Buscar_Siguiente_Libre(void);

/* ------------------------------------------------------------------
 *  Init_Thread_Historial
 * ------------------------------------------------------------------ */
int Init_Thread_Historial(void) {
    colaHistorial = osMessageQueueNew(10, TAMANO_MENSAJE, NULL);
    if (colaHistorial == NULL) return -1;

    tid_Thread_Historial = osThreadNew(Thread_Historial, NULL, NULL);
    if (tid_Thread_Historial == NULL) return -1;

    return 0;
}

/* ------------------------------------------------------------------
 *  Guardar_En_Historial
 *  Construye el slot: [HIST_MAGIC][ "TIPO | TIMESTAMP | DESC\0" ].
 * ------------------------------------------------------------------ */
void Guardar_En_Historial(const char* tipo_evento,
                          const char* timestamp,
                          const char* descripcion) {
    char slot[TAMANO_MENSAJE];

    /* byte[0] = marca; el texto empieza en byte[1] */
    slot[0] = (char)HIST_MAGIC;
    snprintf(&slot[1], TAMANO_MENSAJE - 1, "%s | %s | %s",
             tipo_evento, timestamp, descripcion);

    osMessageQueuePut(colaHistorial, slot, 0U, 0U);
}

/* ------------------------------------------------------------------
 *  Leer_De_Historial
 *  Lee el slot completo, valida la marca y devuelve solo el TEXTO.
 *  Si el slot es libre/corrupto, salida[0] = 0xFF (lo que el CGI ya
 *  interpreta como "celda vacia, abortar iteracion").
 * ------------------------------------------------------------------ */
void Leer_De_Historial(uint32_t indice, char* salida) {
    uint8_t  slot[TAMANO_MENSAJE];
    uint32_t direccion = HISTORIAL_INICIO + (indice * TAMANO_MENSAJE);

    Memoria_ReadData(direccion, slot, TAMANO_MENSAJE);

    if (slot[0] != HIST_MAGIC) {
        salida[0] = (char)0xFF;     /* slot no valido -> el CGI corta aqui */
        return;
    }

    /* Copia el texto (sin la marca), garantizando terminacion */
    memcpy(salida, &slot[1], TAMANO_MENSAJE - 1);
    salida[TAMANO_MENSAJE - 2] = '\0';
}

/* ------------------------------------------------------------------
 *  Historial_Num_Eventos
 * ------------------------------------------------------------------ */
uint32_t Historial_Num_Eventos(void) {
    return g_num_eventos;
}

/* ------------------------------------------------------------------
 *  Historial_Borrar_Todo
 *  Borra 16 sectores (64 KiB = margen de sobra) y reinicia AMBOS:
 *  el contador y el puntero global de escritura. El hilo lee
 *  g_dir_escritura en cada iteracion, asi que ve el reinicio.
 * ------------------------------------------------------------------ */
void Historial_Borrar_Todo(void) {
    for (uint32_t s = 0; s < 16; s++) {
        Memoria_EraseSector(HISTORIAL_INICIO + (s * W25Q_SECTOR_SIZE));
    }

    g_num_eventos   = 0;
    g_dir_escritura = HISTORIAL_INICIO;   /* FASE HIST-v3: corrige el race v2 */
}

/* ------------------------------------------------------------------
 *  Slot_Es_Valido (interna)
 *  Un slot contiene un evento real si su primer byte es HIST_MAGIC.
 *  (Libre = 0xFF; a medias por corte de luz = cualquier otra cosa.)
 * ------------------------------------------------------------------ */
static int Slot_Es_Valido(uint32_t direccion) {
    uint8_t marca = 0;
    Memoria_ReadData(direccion, &marca, 1);
    return (marca == HIST_MAGIC);
}

/* ------------------------------------------------------------------
 *  Buscar_Siguiente_Libre (interna)
 *  Localiza el primer slot SIN marca valida (fin del prefijo escrito).
 *  Busqueda binaria sobre el invariante: izquierda valido, derecha no.
 * ------------------------------------------------------------------ */
static uint32_t Buscar_Siguiente_Libre(void) {
    const uint32_t TOTAL_SLOTS  = W25Q_TOTAL_SIZE / TAMANO_MENSAJE;
    const uint32_t SLOT_INICIAL = HISTORIAL_INICIO / TAMANO_MENSAJE;

    uint32_t izquierda = SLOT_INICIAL;
    uint32_t derecha   = TOTAL_SLOTS - 1U;
    uint32_t primer_libre;

    /* Caso 1: historial vacio (primer slot sin marca) */
    if (!Slot_Es_Valido(HISTORIAL_INICIO)) {
        g_num_eventos = 0;
        return HISTORIAL_INICIO;
    }

    /* Caso 2: historial lleno hasta el final (muy improbable: 16 MB) */
    if (Slot_Es_Valido(derecha * TAMANO_MENSAJE)) {
        g_num_eventos = TOTAL_SLOTS - SLOT_INICIAL;
        return HISTORIAL_INICIO;            /* politica circular */
    }

    /* Busqueda binaria del primer slot NO valido */
    primer_libre = derecha;
    while (izquierda + 1U < derecha) {
        uint32_t medio = (izquierda + derecha) / 2U;
        if (Slot_Es_Valido(medio * TAMANO_MENSAJE)) {
            izquierda = medio;             /* sigue habiendo eventos */
        } else {
            derecha = medio;               /* aqui ya no hay */
            primer_libre = medio;
        }
    }

    g_num_eventos = primer_libre - SLOT_INICIAL;
    return primer_libre * TAMANO_MENSAJE;
}

/* ------------------------------------------------------------------
 *  Thread_Historial
 *  Usa el puntero GLOBAL g_dir_escritura (lo relee cada vuelta, asi
 *  respeta un borrado externo). Borra el sector al cruzar su frontera.
 * ------------------------------------------------------------------ */
static void Thread_Historial(void *argument) {
    (void)argument;
    char slot[TAMANO_MENSAJE];

    g_dir_escritura = Buscar_Siguiente_Libre();

    while (1) {
        osMessageQueueGet(colaHistorial, slot, NULL, osWaitForever);

        uint32_t dir = g_dir_escritura;    /* relee el puntero global */

        /* Inicio de sector nuevo: borrar antes de escribir */
        if ((dir % W25Q_SECTOR_SIZE) == 0U) {
            Memoria_EraseSector(dir);
        }

        Memoria_WritePage(dir, (uint8_t*)slot, TAMANO_MENSAJE);

        /* Avanzar y actualizar contadores */
        dir += TAMANO_MENSAJE;
        g_num_eventos++;

        /* Politica circular al llegar al final del chip */
        if (dir >= W25Q_TOTAL_SIZE) {
            dir = HISTORIAL_INICIO;
        }

        g_dir_escritura = dir;
    }
}